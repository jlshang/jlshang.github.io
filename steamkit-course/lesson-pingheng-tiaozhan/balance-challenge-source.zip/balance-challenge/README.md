# 对称与平衡

2026-11-24 发布版本，22页。02 稳稳转的秘密；03 陀螺变身。

直接打开「对称与平衡_互动课件.html」。源码位于 src/，模型位于 models/。
运行 python3 tools/build.py 可重新生成独立 HTML（需要 Python 3 和 Node.js）。
逐页内容和操作见「逐页讲师稿.md」。tests/ 为 Node.js 核心测试；tools/ 中浏览器验收脚本需配置本机 Playwright/Chrome 路径。
