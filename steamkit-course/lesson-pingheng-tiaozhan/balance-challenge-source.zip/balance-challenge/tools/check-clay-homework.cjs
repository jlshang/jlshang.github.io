const {chromium}=require('../../../tmp/vzome-render/vzw/node_modules/playwright-core'),fs=require('fs'),path=require('path'),a=require('node:assert/strict');
(async()=>{
 const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true,args:['--use-angle=swiftshader','--enable-webgl','--enable-unsafe-swiftshader']});
 try{
  const root=path.resolve(__dirname,'..'),out=root+'/qa/clay-shape-20261124',entry='file://'+root+'/对称与平衡_互动课件.html';
  const p=await browser.newPage({viewport:{width:1600,height:1000}}),errors=[],checks={};
  p.on('pageerror',e=>errors.push(e.message));
  await p.goto(entry+'#p12');await p.waitForFunction(()=>window.LessonApp);await p.evaluate(()=>document.fonts.ready);
  const go=id=>p.evaluate(id=>LessonApp.go(COURSE.pages.findIndex(p=>p.id===id)),id);
  const debug=()=>p.evaluate(()=>LessonApp.debug());
  const snap=name=>p.screenshot({path:out+'/'+name+'.png'});
  const consistent=async()=>{const data=await p.evaluate(()=>{
   const ps=LessonApp.debug().state.clayPoints,area=ClayCore.mass(ps),shown=document.querySelector('[data-clay-center]').dataset.clayCenter.split(',').map(Number);
   return{area,shown,valid:ClayCore.valid(ps),inside:ClayCore.contains(ps,shown),ps,dragging:LessonApp.debug().massDragging};
  });a.ok(data.valid);a.ok(data.shown.every((v,i)=>Math.abs(v-data.area.center[i])<1e-8));return data};
  const screen=(x,y)=>p.locator('.clay-canvas').evaluate((svg,[x,y])=>{const q=new DOMPoint(x,y).matrixTransform(svg.getScreenCTM());return{x:q.x,y:q.y}},[x,y]);
  const begin=async(i=0)=>{const d=await consistent(),q=await screen(...d.ps[i]);await p.mouse.move(q.x,q.y);await p.mouse.down();a.equal((await debug()).massDragging,true)};
  const move=async(x,y)=>{const q=await screen(x,y);await p.mouse.move(q.x,q.y,{steps:10});return consistent()};
  a.equal(await p.locator('h1').textContent(),'重心：一个物体的重量，都集中在这个点。');a.equal(await p.getByText('拖动边缘，捏出不同形状',{exact:true}).count(),0);a.equal(await p.locator('[data-mass-ball]').count(),0);a.equal(await p.locator('[data-clay-preset]').count(),3);a.equal(await p.locator('.page-controls button').count(),1);
  a.equal(await p.locator('[data-clay-reset]').isDisabled(),true);await snap('circle');
  await p.locator('[data-clay-handle="0"]').hover();await snap('hover');await begin();a.equal(await p.locator('.clay-toy.sculpting').count(),1);for(const x of [950,1020,1120]){const d=await move(x,330);a.ok(d.shown[0]>700);a.equal(d.dragging,true)}await snap('drag-feedback');await p.mouse.up();a.equal(await p.locator('.clay-toy.sculpting').count(),0);await snap('sculpted');
  await p.locator('[data-clay-handle="0"]').focus();await p.keyboard.press('ArrowDown');a.equal((await debug()).id,'center-intro');await consistent();
  const saved=(await consistent()).ps;await go('center-point');await go('center-intro');a.deepEqual((await consistent()).ps,saved);
  await p.locator('[data-clay-reset]').click();a.ok(Math.abs((await consistent()).shown[0]-700)<1e-7);
  for(const shape of ['triangle','crescent']){
   await p.locator('[data-clay-preset="'+shape+'"]').click();const d=await consistent();
   if(shape==='crescent'){a.equal(d.inside,false);a.equal(await p.locator('.clay-insight').textContent(),'重心也可以在物体外面')}
   await snap(shape);await begin();await move(1000,450);await p.mouse.up();await consistent();
  }
  for(const action of ['leave','directory','notes','cancel','reset']){
   await p.evaluate(()=>LessonApp.reset());await begin();await move(970,290);
   if(action==='leave'){await go('center-point');await go('center-intro')}
   if(action==='directory'){await p.evaluate(()=>document.querySelector('#directory-button').click());await p.evaluate(()=>document.querySelector('.close-dir').click())}
   if(action==='notes'){await p.evaluate(()=>document.querySelector('#notes-button').click());await p.evaluate(()=>document.querySelector('#notes').close())}
   if(action==='cancel')await p.locator('[data-clay-handle="0"]').dispatchEvent('pointercancel',{pointerId:1});
   if(action==='reset')await p.evaluate(()=>LessonApp.reset());
   a.equal((await debug()).massDragging,false,action);await p.mouse.up();
  }
  await p.locator('[data-clay-preset="crescent"]').click();await p.setViewportSize({width:1024,height:768});await p.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
  await snap('crescent-small');await p.reload();await p.waitForFunction(()=>window.LessonApp);a.equal((await debug()).state.clayPreset,'circle');
  await p.setViewportSize({width:1600,height:1000});
  await p.evaluate(()=>{window.qaViews=new Set();const set=NativeViewer.prototype.set;NativeViewer.prototype.set=function(...args){qaViews.add(this);return set.apply(this,args)}});
  const meshBounds=()=>p.evaluate(()=>{
   const result=[];for(const v of qaViews){if(!v.slot.isConnected||v.no3d)continue;v.scene.updateMatrixWorld(true);v.camera.updateMatrixWorld(true);let x=0,y=0;
    v.modelGroup.traverse(o=>{if(!o.isMesh)return;const ps=o.geometry.attributes.position;for(let i=0;i<ps.count;i++){const q=new THREE.Vector3().fromBufferAttribute(ps,i).applyMatrix4(o.matrixWorld).project(v.camera);x=Math.max(x,Math.abs(q.x));y=Math.max(y,Math.abs(q.y))}});result.push({id:v.id,x,y});
   }return result;
  });
  for(const id of ['homework-tops','homework-tops-2']){
   await go(id);a.ok((await debug()).viewers.every(v=>v.entering));const stages=[];
   for(const delay of [150,450,700]){await p.waitForTimeout(delay);stages.push(await meshBounds())}
   await p.waitForFunction(()=>LessonApp.debug().viewers.every(v=>!v.entering));stages.push(await meshBounds());
   checks[id]={stages};a.ok(stages.flat().every(b=>b.x<1&&b.y<1),JSON.stringify(stages));
   await snap(id);
   const boxes=await p.evaluate(()=>{const title=document.querySelector('h1').getBoundingClientRect();return [...document.querySelectorAll('.model-compare')].map(f=>{const model=f.querySelector('.model-slot').getBoundingClientRect(),name=f.querySelector('.model-name').getBoundingClientRect();return{gapTop:model.top-title.bottom,gapName:name.top-model.bottom,nameBottom:name.bottom,stageBottom:document.querySelector('#stage').getBoundingClientRect().bottom}})});
   a.ok(boxes.every(b=>b.gapTop>=45&&b.gapName>=15&&b.nameBottom<b.stageBottom-80),JSON.stringify(boxes));checks[id].boxes=boxes;
   const final=(await debug()).viewers.map(v=>v.camera);
   await p.waitForTimeout(300);a.deepEqual((await debug()).viewers.map(v=>v.camera),final);
   await go('center-point');await go(id);a.ok((await debug()).viewers.every(v=>v.entering));await p.waitForFunction(()=>LessonApp.debug().viewers.every(v=>!v.entering));
   await p.setViewportSize({width:1024,height:768});await p.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));await snap(id+'-small');await p.setViewportSize({width:1600,height:1000});
  }
  // Candidate stops are captured for choosing views with less rod overlap.
  if(process.env.POSE_PREVIEWS==='1'){
   for(const id of ['homework-tops','homework-tops-2']){await go(id);await p.waitForFunction(()=>LessonApp.debug().viewers.every(v=>!v.entering));
    for(const [i,pose]of [[0,[55,85,85]],[1,[-55,100,85]],[2,[25,100,100]]]){
     await p.evaluate(pose=>{for(const v of qaViews){if(!v.slot.isConnected)continue;v.camera.position.fromArray(pose);v.controls.update();v.camera.zoom=1;v.camera.updateProjectionMatrix();v.fit();v.draw()}},pose);await snap(id+'-candidate-'+i);
    }
   }
  }
  await p.emulateMedia({reducedMotion:'reduce'});await go('center-point');await go('homework-tops');a.ok((await debug()).viewers.every(v=>!v.entering&&v.camera.position[2]>50));
  // Touch drag must remain captured, with no browser pan cancelling the gesture.
  const context=await browser.newContext({viewport:{width:1024,height:768},isMobile:true,hasTouch:true}),tp=await context.newPage();
  tp.on('pageerror',e=>errors.push(e.message));await tp.goto(entry+'#p12');await tp.waitForFunction(()=>window.LessonApp);await tp.evaluate(()=>document.fonts.ready);
  const rect=await tp.locator('[data-clay-handle="0"]').boundingBox(),cdp=await context.newCDPSession(tp),x=rect.x+rect.width/2,y=rect.y+rect.height/2;
  await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x,y}]});
  for(let i=1;i<=5;i++)await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:x+i*18,y:y+i*3}]});
  a.equal(await tp.evaluate(()=>LessonApp.debug().massDragging),true);await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});
  a.equal(await tp.evaluate(()=>LessonApp.debug().massDragging),false);a.ok(await tp.evaluate(()=>ClayCore.mass(LessonApp.debug().state.clayPoints).center[0]>700));
  await tp.screenshot({path:out+'/touch.png'});await context.close();
  a.deepEqual(errors,[]);fs.writeFileSync(out+'/browser-report.json',JSON.stringify({pass:true,checks,errors},null,2));
  console.log('PASS sculpting, polygon COM, presets, mouse/touch/keyboard, lifecycle, repeated entrances, camera stop, model/text separation and small screens');
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
