const {chromium}=require('../../../tmp/vzome-render/vzw/node_modules/playwright-core'),fs=require('fs'),path=require('path'),a=require('node:assert/strict');
(async()=>{
 const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true,args:['--use-angle=swiftshader','--enable-webgl','--enable-unsafe-swiftshader']});
 try{
  const root=path.resolve(__dirname,'..'),out=root+'/qa/lotus-extension-20261124';
  const p=await browser.newPage({viewport:{width:1600,height:1000}}),errors=[],results=[];
  p.on('pageerror',e=>errors.push(e.message));
  await p.goto('file://'+root+'/平衡的挑战_互动课件.html#p20');await p.waitForFunction(()=>window.LessonApp);await p.evaluate(()=>document.fonts.ready);
  // Capture the real rendered viewer for geometric clipping checks.
  await p.evaluate(()=>{const set=NativeViewer.prototype.set;NativeViewer.prototype.set=function(...args){window.qaViewer=this;return set.apply(this,args)};LessonApp.reset();});
  const snap=async name=>p.screenshot({path:out+'/'+name+'.png'});
  const state=()=>p.evaluate(()=>LessonApp.debug());
  const bounds=()=>p.evaluate(()=>{
   const v=window.qaViewer;v.scene.updateMatrixWorld(true);v.camera.updateMatrixWorld(true);
   const pts=[];
   v.modelGroup.traverse(o=>{if(!o.isMesh)return;const pos=o.geometry.attributes.position;for(let i=0;i<pos.count;i++){const q=new THREE.Vector3().fromBufferAttribute(pos,i).applyMatrix4(o.matrixWorld).project(v.camera);pts.push(q);}});
   return {model:v.id,x:Math.max(...pts.map(p=>Math.abs(p.x))),y:Math.max(...pts.map(p=>Math.abs(p.y))),vertices:pts.length};
  });
  const first=await state();a.equal(first.id,'repair-pattern');a.equal(first.viewers[0].fallback,false);await snap('01-start');
  for(let i=0;i<=10;i++){
   if(i)await p.getByRole('button',{name:'增加一组',exact:true}).click();
   const d=await state(),b=await bounds();a.equal(d.state.step,i);a.deepEqual(d.viewers[0].camera,first.viewers[0].camera);
   a.ok(b.x<1&&b.y<1,JSON.stringify(b));a.equal(await p.locator('.mass-overlay').count(),0);
   if(i<10){a.equal(await p.locator('.confetti').count(),0);a.ok(!d.state.completedCelebrated);}
   else {a.equal(d.state.completedCelebrated,true);a.equal(await p.locator('.confetti').count(),1);}
   if(i===10)await p.waitForFunction(()=>!document.querySelector('.confetti'));
   if(i>=6)await snap(String(i+1).padStart(2,'0')+'-'+d.viewers[0].model);
   results.push({step:i,...b});
  }
  a.equal(await p.getByRole('button',{name:'增加一组',exact:true}).count(),0);
  await p.getByRole('button',{name:'切换俯视',exact:true}).click();let b=await bounds();a.ok(b.x<1&&b.y<1,JSON.stringify(b));results.push({view:'top',...b});await snap('12-final-top');
  await p.getByRole('button',{name:'撤回一组',exact:true}).click();a.equal((await state()).state.step,9);
  await p.getByRole('button',{name:'增加一组',exact:true}).click();a.equal(await p.locator('.confetti').count(),0);
  await p.getByRole('button',{name:'回正面',exact:true}).click();b=await bounds();a.ok(b.x<1&&b.y<1);await snap('13-final-front');
  await p.evaluate(()=>LessonApp.go(COURSE.pages.findIndex(p=>p.id==='homework-tops')));a.equal((await state()).id,'homework-tops');
  await p.evaluate(()=>LessonApp.go(COURSE.pages.findIndex(p=>p.id==='repair-pattern')));a.equal((await state()).state.step,10);a.equal(await p.locator('.confetti').count(),0);
  await p.getByRole('button',{name:'重来本页',exact:true}).click();a.equal((await state()).state.step,0);
  await p.evaluate(()=>{for(let i=0;i<10;i++)LessonApp.step(1)});a.equal((await state()).state.step,10);a.equal(await p.locator('.confetti').count(),1);
  await p.setViewportSize({width:1024,height:768});await p.getByRole('button',{name:'切换俯视',exact:true}).click();b=await bounds();a.ok(b.x<1&&b.y<1);await snap('14-small-top');
  await p.reload();await p.waitForFunction(()=>window.LessonApp);a.equal((await state()).state.step,0);
  a.deepEqual(errors,[]);
  fs.writeFileSync(out+'/browser-report.json',JSON.stringify({pass:true,results,errors,checks:['all 11 stages','real native mesh vertices unclipped in oblique/top/front','fixed camera and scale','plus/minus/reset/revisit/reload','no early celebration; completed once; reset allows celebration','1024 and 1600 viewport','adjacent homework retained']},null,2));
  console.log('PASS lotus stages, native mesh bounds, controls and lifecycle');
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
