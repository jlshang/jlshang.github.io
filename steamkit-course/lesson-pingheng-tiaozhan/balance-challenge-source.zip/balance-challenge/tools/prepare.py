from pathlib import Path
import json,math,shutil
R=Path(__file__).resolve().parents[1];root=R.parents[1];source=root/'output/穹顶的奥秘-互动课件-20261120';D=json.load(open(source/'models/assembly.json'));rot=D['rotations'];phi=(1+math.sqrt(5))/2;B=2*phi**2
native=[]
for color,base,prefix in [('blue',[2*phi**2,0,0],'b'),('yellow',[phi**3,0,-phi],'y'),('red',[phi**3,phi**2,0],'r'),('green',[phi**4,phi**2,-1],'g')]:
 for size in range(3):native.append((color,[x*phi**size for x in base],prefix+str(size)))
models={};validation=[]
def add(name,pts,edges,balls,frame=14,center=[0,1.61803398875,0],q=[0,0,0,1]):
 es=[]
 for a,b,color in edges:
  v=[pts[b][j]-pts[a][j] for j in range(3)];found=None
  for c,d,shape in native:
   if c!=color:continue
   for i,r in enumerate(rot):
    if math.dist(v,[sum(r[k][j]*d[j] for j in range(3)) for k in range(3)])<.0001:found=(shape,i);break
   if found:break
  assert found,(name,a,b,color,v)
  shape,i=found;es.append({'a':a,'b':b,'color':color,'shape':shape,'rotation':i});validation.append({'model':name,'a':a,'b':b,'shape':shape,'valid':True})
 models[name]={'points':pts,'balls':balls,'edges':es,'quaternion':q,'center':center,'frame':frame}
# Square spinning top: all points are in the global native connector frame.
p=[[0,0,0],[B,0,0],[0,0,B],[-B,0,0],[0,0,-B],[0,phi*B,0],[0,-B,0],[2*B,0,0],[0,0,2*B],[-2*B,0,0],[0,0,-2*B]]
spokes=[(0,i,'blue') for i in range(1,5)];rim=[(i,1+i%4,'green') for i in range(1,5)];axis=[(0,5,'blue'),(0,6,'blue')];extension=[(i,i+6,'blue') for i in range(1,5)]
add('hub',p,[],[0]);add('two-arms',p,spokes[:2],[0,1,2]);add('spokes',p,spokes,list(range(5)));add('body',p,spokes+rim,list(range(5)));add('low',p,spokes+rim+axis,list(range(5)));high=[x[:] for x in p];high[5]=[0,B,0];high[6]=[0,-phi*B,0];high=[[x,y+(phi-1)*B,z] for x,y,z in high];add('high',high,spokes+rim+axis,list(range(5)))
add('extended',p,spokes+rim+axis+extension,list(range(5)));add('weighted-pair',p,spokes+rim+axis+extension,list(range(5))+[7,9]);add('weighted',p,spokes+rim+axis+extension,list(range(5))+list(range(7,11)))
# New shape/axis comparisons: preserve the whole square body.
# The single green extension follows an existing rim direction, not a guessed hole.
asym=[x[:] for x in p]+[[2*B,0,-B]]
add('asymmetric',asym,spokes+rim+axis+[(1,len(asym)-1,'green')],list(range(5))+[len(asym)-1])
off=[x[:] for x in p];off[5]=[B,phi*B,0];off[6]=[B,-B,0]
add('offcenter',off,spokes+rim+[(1,5,'blue'),(1,6,'blue')],list(range(5)))
# Same blue rods, a different legal blue-hole axis through the SAME centre ball.
direction=next([r[k][0] for k in range(3)] for r in rot if .7<r[1][0]<.9 and r[0][0]>.1)
tilt=[x[:] for x in p];tilt[5]=[x*phi*B for x in direction];tilt[6]=[-x*B for x in direction]
add('tilted',tilt,spokes+rim+axis,list(range(5)))
# Retain original fivefold top as an optional construction gallery with native geometry.
src=root/'output/课程作品方图-光影更新-20261116';orig=json.load(open(src/'制作源码/models.json'))[3]['groups'][0];pts=[b['p'] for b in orig['balls']];e=[(e['a'],e['b'],e['color']) for e in orig['edges']]
x,y,z,w=orig['quaternion'];rr=[[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]];pp=[[sum(rr[k][j]*v[j] for j in range(3)) for k in range(3)] for v in pts];center=[(min(v[k] for v in pp)+max(v[k] for v in pp))/2 for k in range(3)]
add('flower',pts,e,list(range(len(pts))),16,center,orig['quaternion'])
D={'rotations':rot,'models':models,'validation':validation};(R/'src/model-data.js').write_text('window.MODEL_DATA='+json.dumps(D,separators=(',',':'))+';');(R/'models/assembly.json').write_text(json.dumps(D,ensure_ascii=False,indent=2))
for key,name in [('top-p02-1','toy'),('top-p02-3','metal-top'),('top-p05-1','triangle'),('top-p05-2','square'),('top-p05-3','rhombus'),('top-p05-4','trapezoid'),('top-p16-1','red-star'),('top-p19-2','add-rods'),('top-p21-2','add-balls'),('top-p23-1','frame-star'),('top-p25-3','flower-photo')]:
 f=next((source/'reference').glob(key+'.*'));shutil.copy2(f,R/'src/assets'/(name+f.suffix))
for f in (source/'reference').glob('top-*'):shutil.copy2(f,R/'reference'/f.name)
original=src/'原始模型/elHbeFQR.vZome'
if original.exists():shutil.copy2(original,R/'models/原稿花式陀螺.vZome')
# Save exact golden-field meshes for every teaching state, including connector-free rod tips.
def exact(x):
 for denom in [1,2,4]:
  for b in range(-100,101):
   a=round(x*denom-b*phi)
   if abs((a+b*phi)/denom-x)<1e-5:return [a,b,denom]
 raise ValueError(x)
for id,m in models.items():(R/'models'/(id+'.json')).write_text(json.dumps({'field':'golden','vertices':[[exact(x) for x in v] for v in m['points']],'edges':[[e['a'],e['b']] for e in m['edges']],'visibleConnectorVertices':m['balls'],'note':'未列入visibleConnectorVertices的端点是裸杆尖，不额外加球。'},ensure_ascii=False,indent=2))
print('PASS',len(models),'top states,',len(validation),'rod checks')
