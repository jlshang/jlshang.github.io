from pathlib import Path
import json,math,copy
R=Path(__file__).resolve().parents[1];D=json.loads((R/'models/assembly.json').read_text());phi=(1+5**.5)/2;B=2*phi**2
bases={'blue':[B,0,0],'yellow':[phi**3,0,-phi],'red':[phi**3,phi**2,0],'green':[phi**4,phi**2,-1]};vec=[]
for c,v in bases.items():
 for s in range(3):
  for i,r in enumerate(D['rotations']):vec.append((c,c[0]+str(s),i,[sum(r[k][j]*v[j]*phi**s for j in range(3)) for k in range(3)]))
new={}
def add(id,pts,edges,balls,q=[0,0,0,1],frame=16,tip=None):
 es=[]
 for a,b,col in edges:
  v=[pts[b][i]-pts[a][i] for i in range(3)];fits=[x for x in vec if x[0]==col and math.dist(v,x[3])<1e-5];assert fits,(id,a,b,col,v)
  c,shape,rotation,_=fits[0];es.append(dict(a=a,b=b,color=c,shape=shape,rotation=rotation))
 balls=set(balls)
 if tip is not None and any(tip in (e['a'],e['b']) for e in es):balls.add(tip)
 new[id]=dict(points=pts,edges=es,balls=sorted(balls),quaternion=q,center=[0,5,0],frame=frame,tip=tip)
# Red rhombus rim, genuine short-red / medium-yellow hub spokes; raised rim as in source.
p=[[0,B,0],[phi**3,B+phi**2,0],[0,B+phi**2,phi**4],[-phi**3,B+phi**2,0],[0,B+phi**2,-phi**4],[0,B+phi*B,0],[0,0,0]]
rim=[(i,1+i%4,'red') for i in range(1,5)];spokes=[(0,i,'red' if i%2 else 'yellow') for i in range(1,5)];axis=[(0,5,'blue'),(0,6,'blue')]
for name,edges,balls in [('diamond-start',rim[:2],[1,2,3]),('diamond-rim',rim,list(range(1,5))),('diamond-body',rim+spokes,list(range(5))),('diamond',rim+spokes+axis,list(range(6)))]:add(name,p,edges,balls,tip=6)
# Isosceles trapezoid: a reconstruction with a common blue axis to control axis family.
# A cap above hub, native blue bases and yellow sides, not a stretched square.
p=[[B,0,0],[B+phi**2,phi**3,phi],[B+phi**2,-phi**3,phi],[B+phi**2,phi**2,-phi**2],[B+phi**2,-phi**2,-phi**2],[B+phi*B,0,0],[0,0,0]]
rim=[(1,2,'blue'),(2,4,'yellow'),(4,3,'blue'),(3,1,'yellow')];spokes=[(0,1,'blue'),(0,2,'blue'),(0,3,'yellow'),(0,4,'yellow')];axis=[(0,5,'blue'),(0,6,'blue')];q=[0,0,2**-.5,2**-.5]
for name,edges,balls in [('trapezoid-start',rim[:2],[1,2,4]),('trapezoid-rim',rim,list(range(1,5))),('trapezoid-body',rim+spokes,list(range(5))),('trapezoid',rim+spokes+axis,list(range(6)))]:add(name,p,edges,balls,q=q,tip=6)
# Four same-handed blades: four pairs of blue spokes and eight bent green rods.
p=[[0,B,0]];blade=[]
for k in range(4):
 def rot(x,z):
  for _ in range(k):x,z=-z,x
  return [x,B,z]
 mid=len(p);p.append(rot(B,0));outer=len(p);p.append(rot(2*B,0));corner=len(p);p.append(rot(B,B));blade.append([(0,mid,'blue'),(mid,outer,'blue'),(0,corner,'green'),(corner,outer,'green')])
up=len(p);p.append([0,B+phi*B,0]);tip=len(p);p.append([0,0,0]);axis=[(0,up,'blue'),(0,tip,'blue')];body=[e for group in blade for e in group]
for n in range(5):
 es=[e for g in blade[:n] for e in g];balls={0}|{j for a,b,_ in es for j in (a,b)};add('fan-blade-'+str(n),p,es,balls,frame=19,tip=tip)
add('fan',p,body+axis,range(up+1),frame=19,tip=tip)
hi=copy.deepcopy(p)
for i in range(up):hi[i][1]=phi*B
add('fan-high',hi,body+axis,range(up+1),frame=19,tip=tip)
missing=body[:-4]+axis;balls={j for a,b,_ in missing for j in(a,b)}-{tip};add('fan-missing',hi,missing,balls,frame=19,tip=tip)
# Same-colour short-blue decorations in rotationally corresponding radial positions.
decp=copy.deepcopy(p);decs=[]
for k in range(4):
 i=2+3*k;x,_,z=p[i];j=len(decp);decp.append([x*1.5,B,z*1.5]);decs.append((i,j,'blue'))
for n in range(1,5):add('fan-decor-'+str(n),decp,body+axis+decs[:n],list(range(up+1))+list(range(len(p),len(p)+n)),frame=24,tip=tip)
# Source PPT18–23: five red rays, alternating yellow rays, connectors, star rim.
# All directions come from native icosahedral vectors; not a flattened drawing.
u=[x/math.sqrt(sum(t*t for t in bases['red'])) for x in bases['red']]
def dot(v):return sum(a*b for a,b in zip(v,u))
def unique(c,shape):
 out=[]
 for col,sh,rot,v in vec:
  if col==c and sh==shape and not any(math.dist(v,w)<1e-6 for w in out):out.append(v)
 return out
rs=[v for v in unique('red','r0') if abs(dot(v)-math.sqrt(sum(x*x for x in bases['red']))/math.sqrt(5))<1e-5]
ys=[v for v in unique('yellow','y1') if abs(dot(v)-1.3763819204711736)<1e-5]
assert len(rs)==len(ys)==5
hub=bases['red'];rp=[hub]+[[a+b for a,b in zip(hub,v)] for v in rs+ys]
rp += [[a+b*phi for a,b in zip(hub,bases['red'])],[0,0,0]]
# Rotation taking native red axis u to world up.
qv=[-u[2],0,u[0]];qw=1+u[1];ql=math.sqrt(sum(x*x for x in qv)+qw*qw);rq=[x/ql for x in qv]+[qw/ql]
ra=[(0,11,'red'),(0,12,'red')];rr=[(0,i,'red') for i in range(1,6)];yr=[(0,i,'yellow') for i in range(6,11)];rim=[]
for i in range(1,6):
 for j in range(6,11):
  dv=[rp[j][k]-rp[i][k] for k in range(3)]
  if any(c=='yellow' and sh=='y0' and math.dist(dv,v)<1e-5 for c,sh,r,v in vec):rim.append((i,j,'yellow'))
assert len(rim)==10
for name,edges,balls in [('upgrade-red',rr+ra,[0,11,12]),('upgrade-rays',rr+yr+ra,[0,11,12]),('upgrade-balls',rr+yr+ra,range(13)),('upgrade-rim',rr+yr+ra+rim,range(13))]:
 add(name,rp,edges,balls,q=rq,frame=15,tip=12)
# The repair task starts off-balance and high, then restores symmetry and lowers the surface.
rh=copy.deepcopy(rp)
for i in range(11):rh[i]=[v+(phi-1)*hub[j] for j,v in enumerate(rp[i])]
add('upgrade-red-high',rh,rr+ra,[0,11,12],q=rq,frame=15,tip=12)
add('upgrade-missing-high',rh,rr[:-1]+ra,[0,11,12],q=rq,frame=15,tip=12)
# Readable ideal mass model, never claimed to be calibrated plastic masses.
for id,m in new.items():
 parts=[(1,m['points'][i]) for i in m['balls']]
 for e in m['edges']:
  a,b=(m['points'][e[x]] for x in ['a','b']);parts.append((.10*math.dist(a,b),[(x+y)/2 for x,y in zip(a,b)]))
 mass=sum(x[0] for x in parts);m['comLocal']=[sum(w*p[i] for w,p in parts)/mass for i in range(3)];m['idealMass']=mass
 m['massAssumption']='球=1；杆=每坐标长度0.10；杆质量置于端点中点（绿杆弯折忽略）；未称量。'
D['models'].update(new);D['validation']=[x for x in D['validation'] if x.get('model') not in new]+[dict(model=id,a=e['a'],b=e['b'],shape=e['shape'],valid=True) for id,m in new.items() for e in m['edges']]
(R/'models/assembly.json').write_text(json.dumps(D,ensure_ascii=False,indent=2));(R/'src/model-data.js').write_text('window.MODEL_DATA='+json.dumps(D,separators=(',',':'))+';')
def golden(v):
 error,a,b,den=min((abs((a+b*phi)/den-v),a,b,den) for den in (1,2) for b in range(-80,81) for a in [round(v*den-b*phi)])
 assert error<1e-5
 divisor=math.gcd(math.gcd(a,b),den);return [a//divisor,b//divisor,den//divisor]
for id in ['diamond','trapezoid','fan','fan-high','fan-missing','fan-decor-4','upgrade-red','upgrade-rays','upgrade-balls','upgrade-rim','upgrade-red-high','upgrade-missing-high']:
 m=new[id];doc=dict(field='golden',vertices=[[golden(v) for v in p] for p in m['points']],edges=[[e['a'],e['b']] for e in m['edges']],faces=[])
 # Imported endpoint connectors match the visible stage, including the new bottom ball.
 used={j for e in m['edges'] for j in (e['a'],e['b'])};deletes=''
 for j in sorted(used-set(m['balls'])):
  values=[golden(v) for v in m['points'][j]];assert all(v[2]==1 for v in values)
  point=' '.join(str(t) for v in values for t in v[:2])
  deletes+='<DeselectAll/><SelectManifestation point="'+point+'"/><Delete/>'
 count=3+3*len(used-set(m['balls']))
 xml='<?xml version="1.0" encoding="UTF-8"?><vzome:vZome xmlns:vzome="http://xml.vzome.com/vZome/4.0.0/" edition="online" version="1.0" field="golden"><EditHistory editNumber="'+str(count)+'" lastStickyEdit="-1"><SelectAll/><Delete/><ImportSimpleMeshJson scaleAndProject="true" scale="1 0">'+json.dumps(doc)+'</ImportSimpleMeshJson>'+deletes+'</EditHistory><SymmetrySystem name="icosahedral" renderingStyle="lifelike"/></vzome:vZome>'
 (R/'models'/(id+'.vZome')).write_text(xml);(R/'models'/(id+'-native.json')).write_text(json.dumps(m,ensure_ascii=False,indent=2))
(R/'qa/lesson1-native.json').write_text(json.dumps({'models':list(new),'rodChecks':sum(len(m['edges']) for m in new.values()),'source':'原PPT形状参考，依据原生杆长孔向重构。梯形改为标准蓝轴，不声称逐杆还原原图。','engineImportVerified':False,'physicalBuildVerified':False},ensure_ascii=False,indent=2));print('PASS',len(new),'models')
