"""Append the user's exact native lotus geometry to the existing P23 structure."""
from pathlib import Path
import copy
import hashlib
import json
import math

R = Path(__file__).resolve().parents[1]
SOURCE = R / 'reference/vz-models-20261124'
D = json.loads((R / 'models/assembly.json').read_text())
phi = (1 + math.sqrt(5)) / 2
base = D['models']['upgrade-down-hub']
bases = {'blue': [2*phi**2, 0, 0], 'yellow': [phi**3, 0, -phi],
         'red': [phi**3, phi**2, 0], 'green': [phi**4, phi**2, -1]}
vectors = [(color, color[0]+str(size), ri,
            [sum(rot[k][j]*v[j]*phi**size for j in range(3)) for k in range(3)])
           for color, v in bases.items() for size in range(3)
           for ri, rot in enumerate(D['rotations'])]

def load(name):
    doc = json.loads((SOURCE / name).read_text())
    points = [[(v[0]+v[1]*phi)/v[2] for v in p] for p in doc['vertices']]
    return doc, points

def edge_key(e):
    return tuple(sorted((e['a'], e['b'])))

def import_model(name, keep_edges=None):
    doc, points = load(name)
    model = copy.deepcopy(base)
    # Preserve all original indices, including unused vertices, so existing parts
    # retain their positions and identity during every plus/minus operation.
    mapping = {}
    for i, p in enumerate(points):
        j = next((j for j, q in enumerate(model['points']) if math.dist(p, q)<1e-6), None)
        if j is None:
            j = len(model['points'])
            model['points'].append(p)
        mapping[i] = j
    incoming = doc['draft']['mesh']['struts']
    if keep_edges is not None:
        incoming = [e for i, e in enumerate(incoming) if i in keep_edges]
    used = {0, 6, 7}
    for e in incoming:
        a, b = e['vertices']
        used.update((a, b))
        key = tuple(sorted((mapping[a], mapping[b])))
        if any(edge_key(old) == key for old in model['edges']):
            continue
        delta = [points[b][k]-points[a][k] for k in range(3)]
        match = next((v for v in vectors if math.dist(v[3], delta)<1e-5), None)
        assert match, (name, a, b, 'not a native rod')
        color, shape, rotation, _ = match
        model['edges'].append(dict(a=mapping[a], b=mapping[b], color=color,
                                  shape=shape, rotation=rotation))
    model['balls'] = sorted(set(model['balls']) |
                            {mapping[b['vertex']] for b in doc['draft']['mesh']['balls']
                             if b['vertex'] in used})
    model['frame'] = 32
    model['source'] = 'reference/vz-models-20261124/' + name
    model['sourceNote'] = '原生球位与杆连接；保留课件原有五根中红中心加固棍。'
    parts = [(1, model['points'][i]) for i in model['balls']]
    for e in model['edges']:
        a, b = (model['points'][e[k]] for k in ('a', 'b'))
        parts.append((.1*math.dist(a, b), [(x+y)/2 for x, y in zip(a, b)]))
    model['idealMass'] = sum(w for w, _ in parts)
    model['comLocal'] = [sum(w*p[k] for w, p in parts)/model['idealMass'] for k in range(3)]
    return model, mapping

# A is exactly the existing lower pentagonal skirt, before five hub braces.
a_model, _ = import_model('A_low_core.lite.json')
assert a_model['points'] == base['points']
assert a_model['edges'] == base['edges']
assert a_model['balls'] == base['balls']

# First open all five petals with two short-yellow branches each, then close
# all five tips. Each click keeps fivefold symmetry.
open_edges = set(range(42)) | {42+4*i+j for i in range(5) for j in (0, 1)}
specs = [
    ('upgrade-star-base', 'B_star_base.lite.json', None),
    ('upgrade-star-lotus', 'C_star_lotus.lite.json', None),
    ('upgrade-lotus-open', 'D_lotus_bloom.lite.json', open_edges),
    ('upgrade-lotus-bloom', 'D_lotus_bloom.lite.json', None),
]
manifest = {'sourceFiles': {}, 'stages': [], 'preservedHubBraces': 5,
            'physicalBuildVerified': False}
for f in SOURCE.glob('*.lite.json'):
    manifest['sourceFiles'][f.name] = hashlib.sha256(f.read_bytes()).hexdigest()

def golden(value):
    error, a, b, den = min((abs((a+b*phi)/den-value), a, b, den)
                          for den in (1, 2) for b in range(-100, 101)
                          for a in [round(value*den-b*phi)])
    assert error < 1e-5
    g = math.gcd(math.gcd(a, b), den)
    return [a//g, b//g, den//g]

for id, name, edges in specs:
    model, mapping = import_model(name, edges)
    D['models'][id] = model
    (R / 'models' / (id+'-native.json')).write_text(json.dumps(model, ensure_ascii=False, indent=2))
    # Every occupied endpoint in these complete groups has a visible ball.
    occupied = sorted(model['balls'])
    export_ids = {old: new for new, old in enumerate(occupied)}
    mesh = dict(field='golden', vertices=[[golden(v) for v in model['points'][i]] for i in occupied],
                edges=[[export_ids[e['a']], export_ids[e['b']]] for e in model['edges']], faces=[])
    xml = ('<?xml version="1.0" encoding="UTF-8"?>'
           '<vzome:vZome xmlns:vzome="http://xml.vzome.com/vZome/4.0.0/" edition="online" version="1.0" field="golden">'
           '<EditHistory editNumber="3" lastStickyEdit="-1"><SelectAll/><Delete/>'
           '<ImportSimpleMeshJson scaleAndProject="true" scale="1 0">'+json.dumps(mesh)+
           '</ImportSimpleMeshJson></EditHistory><SymmetrySystem name="icosahedral" renderingStyle="lifelike"/></vzome:vZome>')
    (R / 'models' / (id+'.vZome')).write_text(xml)
    manifest['stages'].append(dict(id=id, source=name, balls=len(model['balls']),
                                   rods=len(model['edges']), sourceVertexMapping=mapping))

ids = {s[0] for s in specs}
D['validation'] = [v for v in D['validation'] if v.get('model') not in ids]
D['validation'] += [dict(model=id, a=e['a'], b=e['b'], shape=e['shape'], valid=True)
                    for id in ids for e in D['models'][id]['edges']]
(R / 'models/assembly.json').write_text(json.dumps(D, ensure_ascii=False, indent=2))
(R / 'src/model-data.js').write_text('window.MODEL_DATA='+json.dumps(D, separators=(',', ':'))+';')
qa = R / 'qa/lotus-extension-20261124'
qa.mkdir(parents=True, exist_ok=True)
(qa / 'import-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
print('PASS native imports:', [(s['id'], s['balls'], s['rods']) for s in manifest['stages']])
