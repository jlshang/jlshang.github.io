from pathlib import Path
import re,base64,mimetypes,hashlib,json,subprocess
R=Path(__file__).resolve().parents[1];S=R/'src'
def data(p):return 'data:'+(mimetypes.guess_type(p.name)[0] or 'application/octet-stream')+';base64,'+base64.b64encode(p.read_bytes()).decode()
h=(S/'index.html').read_text();css=(S/'styles.css').read_text();css=re.sub(r"url\(['\"]?(\./assets/[^)'\"\s]+)['\"]?\)",lambda m:'url("'+data(S/m[1])+'")',css);h=h.replace('<link rel="stylesheet" href="./styles.css">','<style>'+css+'</style>')
def js(m):
 s=(S/m[1]).read_text();s=re.sub(r'\./assets/[\w./-]+\.(?:jpeg|jpg|webp|png|mp3)',lambda a:data(S/a[0]),s)
 return '<script>'+s.replace('</script','<\\/script')+'</script>'
h=re.sub(r'<script src="(\./[^"]+)"></script>',js,h);h=h.replace('</head>','<!-- Third-party license notices:\n'+'\n'.join(f.read_text().replace('--','—') for f in (S/'licenses').glob('*'))+'\n-->\n</head>');c=json.loads(subprocess.check_output(['node','-e','global.window={};require('+json.dumps(str(S/'content.js'))+');console.log(JSON.stringify(window.COURSE))']).decode());title=c['title'];out=R/(title+'_互动课件.html');out.write_text(h)
# Keep already-open local/HTTP lesson links current after a course-title rename.
for alias in c.get('legacyEntries',[]):
 if Path(alias).name != alias or not alias.endswith('.html'):
  raise ValueError('Legacy entry must be a local HTML filename')
 (R/alias).write_text(h)
notes='# '+title+' · 逐页讲师稿\n\n'+c['minutes']+'。未实搭，未试教。\n\n桌面浏览器打开同目录HTML。← → 翻页，空格推进，G目录，N备注，F全屏。输入框内由输入接管键盘。课内回翻保留进度，刷新清空记录，请先导出。\n\n'
for i,p in enumerate(c['pages']):
 notes+=f"## {i+1:02d} {p['title']}\n\n稳定ID：`{p['id']}`｜{p['section']}\n\n{p['notes']}\n\n"
 if p.get('stages'):notes+='拼搭状态：\n'+''.join(f"- {j+1}. {s['label']}（模型 `{s['model']}`）\n" for j,s in enumerate(p['stages']))+'\n'
 elif p.get('reveal'):notes+='教师揭晓：'+p['reveal']+'\n\n'
(R/'逐页讲师稿.md').write_text(notes);(R/'qa/build.json').write_text(json.dumps({'entry':out.name,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'bytes':len(h.encode()),'pages':len(c['pages'])},ensure_ascii=False,indent=2));print(out,'pages',len(c['pages']),'bytes',len(h.encode()))
