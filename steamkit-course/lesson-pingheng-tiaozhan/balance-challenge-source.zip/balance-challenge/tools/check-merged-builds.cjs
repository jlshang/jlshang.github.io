const {chromium}=require('../../../tmp/vzome-render/vzw/node_modules/playwright-core'),fs=require('fs'),path=require('path'),a=require('node:assert/strict');
(async()=>{
 const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true,args:['--use-angle=swiftshader','--enable-webgl','--enable-unsafe-swiftshader']});
 try{
  const root=path.resolve(__dirname,'..'),out=root+'/qa/merged-builds-20261124',p=await browser.newPage({viewport:{width:1600,height:1000}}),errors=[],routes=[];
  p.on('pageerror',e=>errors.push(e.message));
  const debug=()=>p.evaluate(()=>LessonApp.debug());
  for(const [first,name] of [['diamond','红杆菱形'],['trapezoid','等腰梯形'],['fan','旋转扇面']]){
   await p.goto('file://'+root+'/平衡的挑战_互动课件.html#p5');await p.reload();await p.waitForFunction(()=>window.LessonApp);await p.evaluate(()=>document.fonts.ready);
   await p.evaluate(()=>{const set=NativeViewer.prototype.set;NativeViewer.prototype.set=function(...args){window.qaViewer=this;return set.apply(this,args)}});
   await p.getByRole('button',{name:'先搭'+name,exact:true}).click();
   const order=[first,...['diamond','trapezoid','fan'].filter(x=>x!==first)];
   const visited=[];
   for(const id of order){
    let d=await debug();a.equal(d.id,id+'-build');a.equal(d.state.step,0);a.equal(d.order.length,22);a.equal(d.order.filter(x=>x.endsWith('-axis')).length,0);
    const last=id==='fan'?5:3,camera=d.viewers[0].camera;
    for(let step=1;step<=last;step++){
     await p.getByRole('button',{name:'增加一组',exact:true}).click();d=await debug();a.equal(d.id,id+'-build');a.equal(d.state.step,step);if(step<last)a.deepEqual(d.viewers[0].camera,camera);else a.ok(d.viewers[0].camera.position[2]>50);a.equal(d.viewers[0].fallback,false);
    }
    a.equal(d.viewers[0].model,id);a.equal(await p.getByRole('button',{name:'增加一组',exact:true}).count(),0);
    const meshBounds=await p.evaluate(()=>{
     const v=qaViewer;v.scene.updateMatrixWorld(true);v.camera.updateMatrixWorld(true);
     let x=0,y=0;v.modelGroup.traverse(o=>{if(!o.isMesh)return;const ps=o.geometry.attributes.position;for(let i=0;i<ps.count;i++){const q=new THREE.Vector3().fromBufferAttribute(ps,i).applyMatrix4(o.matrixWorld).project(v.camera);x=Math.max(x,Math.abs(q.x));y=Math.max(y,Math.abs(q.y));}});
     return {x,y};
    });a.ok(meshBounds.x<1&&meshBounds.y<1,JSON.stringify({id,...meshBounds}));
    if(first==='diamond')await p.screenshot({path:out+'/'+id+'-complete.png'});
    await p.getByRole('button',{name:'撤回一组',exact:true}).click();a.equal((await debug()).state.step,last-1);
    await p.getByRole('button',{name:'增加一组',exact:true}).click();a.equal((await debug()).viewers[0].model,id);
    await p.locator('#next').click();await p.locator('#previous').click();a.equal((await debug()).state.step,last);
    await p.getByRole('button',{name:'重来本页',exact:true}).click();a.equal((await debug()).state.step,0);
    await p.locator('#next').click();visited.push({id,meshBounds});
   }
   a.equal((await debug()).id,'spin-compare');routes.push({first,visited});
  }
  await p.locator('#directory-button').click();a.equal(await p.locator('.directory-card').count(),22);
  a.equal(await p.getByRole('button',{name:/装好转杆，再检查/}).count(),0);
  await p.getByRole('button',{name:'关闭目录',exact:true}).click();
  await p.evaluate(()=>LessonApp.go(COURSE.pages.findIndex(p=>p.id==='center-intro')));a.equal((await debug()).index,11);a.equal(await p.locator('[data-clay-reset]').count(),1);
  await p.evaluate(()=>LessonApp.go(COURSE.pages.findIndex(p=>p.id==='repair-pattern')));a.equal((await debug()).index,19);a.equal(await p.locator('.progress-dots .dot').count(),11);
  a.deepEqual(errors,[]);
  fs.writeFileSync(out+'/browser-report.json',JSON.stringify({pass:true,routes,errors,checks:['all three first-choice routes','one page per top including shaft','overhead surface then oblique shaft','plus/minus/reset/revisit','22 directory entries without separate shaft pages','native geometry unclipped','center and lotus page indices updated']},null,2));
  console.log('PASS three merged building pages and all first-choice routes');
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
