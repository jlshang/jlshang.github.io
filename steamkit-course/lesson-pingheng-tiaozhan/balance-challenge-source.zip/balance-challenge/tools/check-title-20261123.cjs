const {chromium}=require('../../../tmp/vzome-render/vzw/node_modules/playwright-core');
const path=require('path'),fs=require('fs'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..');
(async()=>{
 const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true,args:['--use-angle=swiftshader','--enable-webgl','--ignore-gpu-blocklist','--enable-unsafe-swiftshader']});
 try {
  const p=await browser.newPage({viewport:{width:1600,height:974},reducedMotion:'reduce'}),errors=[];
  p.on('pageerror',e=>errors.push(e.message));
  await p.goto('file://'+path.join(root,'平衡的挑战_互动课件.html')+'#p18');
  await p.waitForFunction(()=>window.LessonApp);
  await p.evaluate(()=>document.fonts.ready);
  async function check(){
   assert.equal(await p.locator('h1').textContent(),'哪个转的更稳');
   assert.equal(await p.evaluate(()=>LessonApp.debug().id),'height-compare');
   assert.equal(await p.evaluate(()=>LessonApp.debug().index),17);
   assert.equal(await p.locator('h1').evaluate(e=>e.scrollWidth>e.clientWidth+2),false);
   assert.ok(await p.evaluate(()=>LessonApp.debug().viewers.length===2&&LessonApp.debug().viewers.every(v=>!v.fallback)));
  }
  await check();
  await p.evaluate(()=>LessonApp.go(16));await p.evaluate(()=>LessonApp.go(17));await check();
  await p.evaluate(()=>LessonApp.go(18));await p.evaluate(()=>LessonApp.go(17));await check();
  await p.getByRole('button',{name:'重来本页',exact:true}).click();await check();
  await p.reload();await p.waitForFunction(()=>window.LessonApp);await check();
  await p.screenshot({path:path.join(root,'qa/title-20261123.png')});
  assert.deepEqual(errors,[]);
  fs.writeFileSync(path.join(root,'qa/title-browser-20261123.json'),JSON.stringify({pass:true,title:'哪个转的更稳',page:18,checks:['title','two native models','no title overflow','adjacent page return','reset','refresh'],errors},null,2));
  console.log('PASS: title, two native models, adjacent return, reset, refresh');
 } finally {await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
