/* Render the original native Zometool meshes orthographically; no invented ball/rod geometry. */
const {chromium}=require('../../../tmp/vzome-render/vzw/node_modules/playwright-core');
const fs=require('fs'),path=require('path');
(async()=>{const root=path.resolve(__dirname,'..'),b=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true,args:['--use-angle=swiftshader','--enable-webgl','--enable-unsafe-swiftshader']});try{
 const p=await b.newPage();await p.goto('about:blank');
 for(const f of ['assets/three.min.js','assets/shapes.js','model-data.js'])await p.addScriptTag({path:path.join(root,'src',f)});
 const model=JSON.parse(fs.readFileSync(path.join(root,'models/center-hunt-key-native.json')));
 const image=await p.evaluate(m=>{
  const T=THREE,r=new T.WebGLRenderer({alpha:true,antialias:true,preserveDrawingBuffer:true});r.setSize(1560,1140);r.setClearColor(0,0);r.outputEncoding=T.sRGBEncoding;r.toneMapping=T.ACESFilmicToneMapping;r.toneMappingExposure=1.05;
  const scene=new T.Scene(),cx=5.23606797749979,cz=0,cam=new T.OrthographicCamera(-260/20,260/20,190/20,-190/20,.1,500);cam.position.set(cx,-100,cz);cam.up.set(0,0,1);cam.lookAt(cx,m.points[0][1],cz);
  scene.add(new T.HemisphereLight(0xffffff,0x819ab3,.65));for(const [v,pos]of [[1,[0,-60,60]],[.55,[-50,-20,0]],[.4,[50,20,-30]]]){const light=new T.DirectionalLight(0xffffff,v);light.position.set(...pos);scene.add(light);}
  const geo=name=>{const s=HD_SHAPES[name],g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(s.positions,3));g.setIndex(s.indices);g.computeVertexNormals();return g;};
  const mat=color=>new T.MeshStandardMaterial({color:new T.Color(color).convertSRGBToLinear(),roughness:.42,metalness:.04});
  for(let i=0;i<m.balls.length;i++){const mesh=new T.Mesh(geo('ball'),mat('#eef2f3'));mesh.position.fromArray(m.points[i]);scene.add(mesh);}
  for(const e of m.edges){const mesh=new T.Mesh(geo(e.shape),mat(e.color==='blue'?'#1599e2':'#32ae71')),a=MODEL_DATA.rotations[e.rotation];mesh.setRotationFromMatrix(new T.Matrix4().set(a[0][0],a[0][1],a[0][2],0,a[1][0],a[1][1],a[1][2],0,a[2][0],a[2][1],a[2][2],0,0,0,0,1));mesh.position.fromArray(m.points[e.a]);scene.add(mesh);}
  r.render(scene,cam);const data=r.domElement.toDataURL('image/png');r.dispose();return data;
 },model);
 fs.writeFileSync(path.join(root,'src/assets/center-hunt-zometool.png'),Buffer.from(image.split(',')[1],'base64'));console.log('Rendered new 12-ball / 12-rod key at 20 px per native coordinate unit.');
}finally{await b.close()}})().catch(e=>{console.error(e);process.exitCode=1});
