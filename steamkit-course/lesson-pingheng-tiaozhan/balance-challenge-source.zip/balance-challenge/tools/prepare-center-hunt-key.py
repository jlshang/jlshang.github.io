"""Create a new planar key using only legal short blue Zometool struts."""
from pathlib import Path
import json, math
R=Path(__file__).resolve().parents[1]
phi=(1+5**.5)/2; unit=2+2*phi
# Square handle, two-segment shaft and two downward teeth; not a course top model.
grid=[(-1,1),(0,1),(1,1),(1,0),(1,-1),(0,-1),(-1,-1),(-1,0),(2,0),(3,0),(2,-1),(3,-1)]
links=[(i,(i+1)%8) for i in range(8)]+[(3,8),(8,9),(8,10),(9,11)]
points=[[x*unit,0,z*unit] for x,z in grid]
rotations=json.loads((R/'models/assembly.json').read_text())['rotations']
edges=[]
for a,b in links:
 v=[points[b][k]-points[a][k] for k in range(3)]
 rotation=next(i for i,m in enumerate(rotations) if math.dist(v,[m[k][0]*unit for k in range(3)])<1e-8)
 edges.append(dict(a=a,b=b,color='blue',shape='b0',rotation=rotation))
assumption='球=1；每根短蓝杆=原生坐标长度×0.10；杆质量集中于中点；未称量。'
model=dict(points=points,edges=edges,balls=list(range(12)),quaternion=[0,0,0,1],center=[unit,0,0],frame=15,sourceFile='center-hunt-key.vZome',massAssumption=assumption)
(R/'models/center-hunt-key-native.json').write_text(json.dumps(model,ensure_ascii=False,indent=2))
mesh=dict(field='golden',vertices=[[[2*x,2*x,1],[0,0,1],[2*z,2*z,1]] for x,z in grid],edges=links,faces=[])
xml='<?xml version="1.0" encoding="UTF-8"?><vzome:vZome xmlns:vzome="http://xml.vzome.com/vZome/4.0.0/" edition="online" version="1.0" field="golden"><EditHistory editNumber="3" lastStickyEdit="-1"><SelectAll/><Delete/><ImportSimpleMeshJson scaleAndProject="true" scale="1 0">'+json.dumps(mesh)+'</ImportSimpleMeshJson></EditHistory><SymmetrySystem name="icosahedral" renderingStyle="lifelike"/></vzome:vZome>'
(R/'models/center-hunt-key.vZome').write_text(xml)
nodes=[[(p[0]-unit)*20,-p[2]*20] for p in points]
rods=[dict(e,mass=math.dist(points[e['a']],points[e['b']])*.1) for e in edges]
shape=dict(name='Zometool 小钥匙',kind='zometool',answer='B',decoy=[-unit*20,0],sourceFile='center-hunt-key.vZome',nodes=nodes,ballMasses=[1]*12,rods=rods,points=[nodes[i] for i in [0,2,9,11,6]],holes=[nodes[i] for i in [2,9]],image='./assets/center-hunt-zometool.png',imageBounds=[-260,-190,520,380],massAssumption=assumption)
p=R/'src/center-hunt-core.js';s=p.read_text();start=s.index(' {"name":');end=s.index('\n];',start);p.write_text(s[:start]+' '+json.dumps(shape,ensure_ascii=False,separators=(',',':'))+s[end:])
print('New planar key: 12 balls, 12 native b0 rods; vectors verified; editable vZome saved.')
