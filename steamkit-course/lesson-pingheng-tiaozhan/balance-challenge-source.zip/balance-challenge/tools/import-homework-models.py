"""Import the final active colored mesh without altering the four supplied .vZome files."""
from pathlib import Path
import json, math, hashlib, xml.etree.ElementTree as ET
R=Path(__file__).resolve().parents[1];D=json.loads((R/'models/assembly.json').read_text());phi=(1+5**.5)/2
bases={'blue':[2*phi**2,0,0],'yellow':[phi**3,0,-phi],'red':[phi**3,phi**2,0],'green':[phi**4,phi**2,-1]}
colors={'#0081DF':'blue','#EFA616':'yellow','#B82E45':'red'};vectors=[]
for color,base in bases.items():
 for size in range(3):
  for rotation,m in enumerate(D['rotations']):
   vectors.append((color,color[0]+str(size),rotation,[sum(m[k][j]*base[j]*phi**size for j in range(3)) for k in range(3)]))
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def rotate(p,q):
 t=[2*v for v in cross(q[:3],p)];c=cross(q[:3],t);return [p[i]+q[3]*t[i]+c[i] for i in range(3)]
rows=[]
for name in ['tri-cyclone','star-gear','crystal-crown','double-saucer']:
 file=R/'models'/(name+'.vZome');root=ET.parse(file).getroot();history=root.find('EditHistory');assert int(history.get('editNumber'))==len(history)
 imports=[e for e in history if e.tag=='ImportColoredMeshJson'];assert len(imports)==3
 # Each snapshot is replaced by SelectAll/Delete before the next complete mesh.
 assert history[-1].tag=='ImportColoredMeshJson' and history[-2].tag=='Delete' and history[-3].tag=='SelectAll'
 doc=json.loads(imports[-1].text);assert not doc['panels'];pts=[[(a+b*phi)/den for a,b,den in p]for p in doc['vertices']];edges=[]
 for edge in doc['struts']:
  a,b=edge['vertices'];direction=[pts[b][k]-pts[a][k] for k in range(3)];color=colors[edge['color']]
  fits=[(shape,rotation)for c,shape,rotation,v in vectors if c==color and math.dist(v,direction)<1e-5];assert fits,(name,edge)
  shape,rotation=fits[0];edges.append(dict(a=a,b=b,color=color,displayColor=edge['color'],shape=shape,rotation=rotation))
 up=root.find('./Viewing/ViewModel/UpDirection');u=[float(up.get(k)) for k in ['x','y','z']];length=math.sqrt(sum(x*x for x in u));u=[x/length for x in u]
 q=cross(u,[0,1,0])+[1+u[1]];length=math.sqrt(sum(x*x for x in q));q=[x/length for x in q]
 balls=[b['vertex']for b in doc['balls']];world=[rotate(pts[i],q)for i in balls];center=[(min(p[k]for p in world)+max(p[k]for p in world))/2 for k in range(3)];radius=max(math.dist(p,center)for p in world)
 m=dict(points=pts,edges=edges,balls=balls,ballColors={str(b['vertex']):b['color'] for b in doc['balls']},quaternion=q,center=center,frame=radius*1.12,sourceFile=file.name,sourceSha256=hashlib.sha256(file.read_bytes()).hexdigest())
 D['models'][name]=m;(R/'models'/(name+'-native.json')).write_text(json.dumps(m,ensure_ascii=False,indent=2));rows.append(dict(id=name,balls=len(balls),rods=len(edges),total=len(balls)+len(edges),sourceSha256=m['sourceSha256'],nativeRodVectorsVerified=True,physicalSpinVerified=False))
D['validation']=[r for r in D['validation'] if r.get('model') not in {r['id']for r in rows}]+[dict(model=r['id'],a=e['a'],b=e['b'],shape=e['shape'],valid=True)for r in rows for e in D['models'][r['id']]['edges']]
(R/'models/assembly.json').write_text(json.dumps(D,ensure_ascii=False,indent=2));(R/'src/model-data.js').write_text('window.MODEL_DATA='+json.dumps(D,separators=(',',':'))+';');(R/'qa/homework-model-import.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2));print(json.dumps(rows,ensure_ascii=False,indent=2))
