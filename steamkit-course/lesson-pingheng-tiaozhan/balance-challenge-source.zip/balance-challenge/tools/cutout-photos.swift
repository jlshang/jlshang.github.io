import AppKit
import Vision
import CoreImage
let context = CIContext()
for path in CommandLine.arguments.dropFirst() {
 do {
 let url=URL(fileURLWithPath:path)
 let request=VNGenerateForegroundInstanceMaskRequest()
 let handler=VNImageRequestHandler(url:url)
 try handler.perform([request])
 guard let obs=request.results?.first else { print("EMPTY",path);continue }
 let buffer=try obs.generateMaskedImage(ofInstances:obs.allInstances,from:handler,croppedToInstancesExtent:true)
 let ci=CIImage(cvPixelBuffer:buffer)
 let out=url.deletingPathExtension().appendingPathExtension("cutout.png")
 try context.writePNGRepresentation(of:ci,to:out,format:.RGBA8,colorSpace:CGColorSpace(name:CGColorSpace.sRGB)!)
 print(out.path)
 }catch{ print("ERROR",path,error) }
}
