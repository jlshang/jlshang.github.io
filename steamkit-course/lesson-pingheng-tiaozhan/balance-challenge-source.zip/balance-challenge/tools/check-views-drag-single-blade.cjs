const {chromium}=require('../../../tmp/vzome-render/vzw/node_modules/playwright-core');
const fs=require('fs'),path=require('path'),a=require('node:assert/strict');
(async()=>{
 const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true,args:['--use-angle=swiftshader','--enable-webgl','--enable-unsafe-swiftshader']});
 try{
  const root=path.resolve(__dirname,'..'),out=root+'/qa/views-drag-single-blade-20261124';
  fs.mkdirSync(out,{recursive:true});
  const p=await browser.newPage({viewport:{width:1600,height:1000}}),errors=[],report={};
  p.on('pageerror',e=>errors.push(e.message));
  const entry='file://'+root+'/对称与平衡_互动课件.html';
  await p.goto(entry+'#p5');await p.waitForFunction(()=>window.LessonApp);await p.evaluate(()=>document.fonts.ready);
  await p.evaluate(()=>{window.qaViews=new Set();const set=NativeViewer.prototype.set;NativeViewer.prototype.set=function(...args){qaViews.add(this);return set.apply(this,args)}});
  const debug=()=>p.evaluate(()=>LessonApp.debug());
  const go=id=>p.evaluate(id=>LessonApp.go(COURSE.pages.findIndex(p=>p.id===id)),id);
  const snap=name=>p.screenshot({path:out+'/'+name+'.png'});
  const bounds=()=>p.evaluate(()=>{
   const result=[];
   for(const v of qaViews){if(!v.slot.isConnected||v.no3d)continue;v.scene.updateMatrixWorld(true);v.camera.updateMatrixWorld(true);let x=0,y=0;
    v.modelGroup.traverse(o=>{if(!o.isMesh)return;const ps=o.geometry.attributes.position;for(let i=0;i<ps.count;i++){const q=new THREE.Vector3().fromBufferAttribute(ps,i).applyMatrix4(o.matrixWorld).project(v.camera);x=Math.max(x,Math.abs(q.x));y=Math.max(y,Math.abs(q.y));}});
    result.push({id:v.id,x,y});
   }return result;
  });
  for(const id of ['shape-select','spin-compare']){
   await go('part-shape');await go(id);
   a.ok((await debug()).viewers.every(v=>!v.fallback&&v.camera.position[1]>40&&v.camera.position[2]>50));
   report[id]=await bounds();a.ok(report[id].every(b=>b.x<1&&b.y<1),JSON.stringify(report[id]));
   if(id==='spin-compare'){const before=(await debug()).viewers.map(v=>v.camera);await p.getByRole('button',{name:'显示平衡结果',exact:true}).click();a.deepEqual((await debug()).viewers.map(v=>v.camera),before);}
   await snap(id);
  }
  for(const id of ['diamond','trapezoid','fan']){
   await go(id+'-build');let d=await debug();const camera=d.viewers[0].camera,last=id==='fan'?5:3;
   a.ok(camera.position[1]>89&&Math.abs(camera.position[2])<.01);
   for(let s=1;s<last;s++){await p.getByRole('button',{name:'增加一组',exact:true}).click();a.deepEqual((await debug()).viewers[0].camera,camera);}
   await snap(id+'-surface');
   await p.getByRole('button',{name:'增加一组',exact:true}).click();
   d=await debug();a.equal(d.viewers[0].model,id);a.ok(d.viewers[0].camera.position[2]>50);
   report[id]=await bounds();a.ok(report[id].every(b=>b.x<1&&b.y<1),JSON.stringify(report[id]));await snap(id+'-complete');
   const pose=d.viewers[0].camera;
   await go('part-shape');await go(id+'-build');a.ok((await debug()).viewers[0].camera.position.every((x,i)=>Math.abs(x-pose.position[i])<1e-8));
   await p.getByRole('button',{name:'撤回一组',exact:true}).click();a.deepEqual((await debug()).viewers[0].camera,camera);
   await p.getByRole('button',{name:'重来本页',exact:true}).click();a.equal((await debug()).state.step,0);a.deepEqual((await debug()).viewers[0].camera,camera);
  }
  // P12 is covered by check-clay-homework.cjs.
  await go('center-shift');
  for(const model of ['fan-missing','fan-two-missing','fan-one-blade']){await p.getByRole('button',{name:'移除一片',exact:true}).click();a.equal((await debug()).viewers[0].model,model);a.equal(await p.locator('.mass-overlay').count(),1);}
  a.equal(await p.getByRole('button',{name:'移除一片',exact:true}).count(),0);await snap('single-blade');
  await p.getByRole('button',{name:'补回一片',exact:true}).click();a.equal((await debug()).viewers[0].model,'fan-two-missing');
  await p.getByRole('button',{name:'重来本页',exact:true}).click();a.equal((await debug()).viewers[0].model,'fan-high');
  for(const id of ['homework-tops','homework-tops-2']){
   await go(id);await p.waitForFunction(()=>LessonApp.debug().viewers.every(v=>!v.entering));
   a.ok((await debug()).viewers.every(v=>!v.fallback&&v.camera.position[2]>50));
   const transform=await p.locator('.scene').evaluate(e=>getComputedStyle(e).transform);a.equal(transform,'matrix(1, 0, 0, 1, 0, 52)');
   await snap(id);report[id]=(await debug()).viewers;
   await p.setViewportSize({width:1024,height:768});await snap(id+'-small');await p.setViewportSize({width:1600,height:1000});
  }
  a.deepEqual(errors,[]);fs.writeFileSync(out+'/browser-report.json',JSON.stringify({pass:true,report,errors},null,2));
  console.log('PASS views, stage camera transitions, one blade, homework layout');
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
