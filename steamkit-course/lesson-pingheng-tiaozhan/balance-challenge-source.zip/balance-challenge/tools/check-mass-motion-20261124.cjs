// P12 now sculpts one uniform sheet; use the current browser regression.
require('./check-clay-homework.cjs');
