(function(g){
 'use strict';
 const C={
  responseText(p,s){if(p.completionReveal)return s.step===p.stages.length-1?p.completionReveal:null;return s.revealed?p.reveal:null},
  clampStep:(n,count)=>Math.max(0,Math.min(count-1,n)),
  number(value){const s=String(value).trim().replace(/[０-９]/g,c=>String(c.charCodeAt(0)-65296)).replace('．','.');return /^\d+(?:\.\d+)?$/.test(s)&&Number.isFinite(+s)?+s:null},
  mean(values){const n=values.map(C.number).filter(x=>x!==null);return n.length?n.reduce((a,b)=>a+b,0)/n.length:null},
  clearRecordRows(rows,indices){return rows.map((row,i)=>indices.includes(i)?row.map(()=>''):row.slice())},
  shouldHandle(e){return !e.isComposing&&!['INPUT','TEXTAREA','SELECT','BUTTON','A'].includes(e.target?.tagName)&&!e.target?.isContentEditable},
  csv(rows){return '\ufeff'+rows.map(r=>r.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(',')).join('\r\n')},
  edgeKey:e=>[Math.min(e.a,e.b),Math.max(e.a,e.b)].join('-')
 };
 if(typeof module!=='undefined')module.exports=C;g.LessonCore=C;
})(typeof window==='undefined'?globalThis:window);
