/* Geometry icon renderer copied from lesson05-kongjian-dalishi. */
(function(root){'use strict';
function shapeIcon(kind,size=64){const s=size,h=s/2,pts=n=>Array.from({length:n},(_,i)=>{const a=-Math.PI/2+i*2*Math.PI/n;return`${h+h*.86*Math.cos(a)},${h+h*.86*Math.sin(a)+(n===3?h*.14:0)}`}).join(" ");
  const st=`fill="#DCEBFF" stroke="#1d6fd0" stroke-width="${s/12}" stroke-linejoin="round"`;
  const body=kind==="trapezoid"?`<polygon points="${s*.3},${s*.18} ${s*.7},${s*.18} ${s*.93},${s*.82} ${s*.07},${s*.82}" ${st}/>`:kind==="rot"?`<path d="M${h} ${h}L${s*.92} ${h}L${s*.71} ${s*.29}Z M${h} ${h}L${h} ${s*.08}L${s*.29} ${s*.29}Z M${h} ${h}L${s*.08} ${h}L${s*.29} ${s*.71}Z M${h} ${h}L${h} ${s*.92}L${s*.71} ${s*.71}Z" ${st}/>`:kind==="tri"?`<polygon points="${pts(3)}" ${st}/>`:kind==="sq"?`<rect x="${s*.14}" y="${s*.14}" width="${s*.72}" height="${s*.72}" ${st}/>`:kind==="rect"?`<rect x="${s*.04}" y="${s*.26}" width="${s*.92}" height="${s*.5}" ${st}/>`:
    kind==="pe"?`<polygon points="${pts(5)}" ${st}/>`:kind==="hex"?`<polygon points="${pts(6)}" ${st}/>`:kind==="circ"?`<circle cx="${h}" cy="${h}" r="${h*.82}" ${st}/>`:`<text x="${h}" y="${h*1.3}" font-size="${s*.8}" text-anchor="middle" fill="#1d6fd0" font-weight="900">?</text>`;
  return `<svg viewBox="0 0 ${s} ${s}" width="${s}" height="${s}" aria-hidden="true">${body}</svg>`}
const kinds={"有轴对称就够了":"trapezoid","旋转对称更容易配平":"rot","必须两种对称都有":"sq","三角形":"tri","正方形":"sq","长方形":"rect","五边形":"pe","六边形":"hex","圆形":"circ","五边形的角还能变":"pe","连接处可能会动":"other","不是三角形":"sq"};
function kindOf(text){return kinds[text]||'other';}
const api={shapeIcon,kindOf};if(typeof module!=='undefined')module.exports=api;else root.SurveyIcons=api;
})(typeof window!=='undefined'?window:globalThis);
