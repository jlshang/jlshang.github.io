(function(g){'use strict';
const cross=(a,b,c)=>(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);
const C={
 mass(ps){
  let twiceArea=0,x=0,y=0;
  ps.forEach((p,i)=>{const q=ps[(i+1)%ps.length],k=p[0]*q[1]-q[0]*p[1];twiceArea+=k;x+=(p[0]+q[0])*k;y+=(p[1]+q[1])*k});
  return {area:Math.abs(twiceArea)/2,center:[x/(3*twiceArea),y/(3*twiceArea)]};
 },
 contains(ps,[x,y]){
  let inside=false;
  for(let i=0,j=ps.length-1;i<ps.length;j=i++){const p=ps[i],q=ps[j];if((p[1]>y)!==(q[1]>y)&&x<(q[0]-p[0])*(y-p[1])/(q[1]-p[1])+p[0])inside=!inside}
  return inside;
 },
 simple(ps){
  const n=ps.length;
  for(let i=0;i<n;i++){
   const a=ps[i],b=ps[(i+1)%n];
   if(Math.hypot(a[0]-b[0],a[1]-b[1])<.5)return false;
   for(let j=i+2;j<n;j++){
    if(i===0&&j===n-1)continue;
    const c=ps[j],d=ps[(j+1)%n];
    if(Math.max(a[0],b[0])<Math.min(c[0],d[0])||Math.max(c[0],d[0])<Math.min(a[0],b[0])||Math.max(a[1],b[1])<Math.min(c[1],d[1])||Math.max(c[1],d[1])<Math.min(a[1],b[1]))continue;
    if(cross(a,b,c)*cross(a,b,d)<=1e-7&&cross(c,d,a)*cross(c,d,b)<=1e-7)return false;
   }
  }
  return true;
 },
 valid(ps){return ps.every(p=>p.every(Number.isFinite))&&C.mass(ps).area>9000&&C.simple(ps)},
 preset(name){
  if(name==='triangle'){
   const corners=[[700,110],[930,410],[470,410]],ps=[];
   corners.forEach((p,i)=>{const q=corners[(i+1)%3];for(let j=0;j<20;j++)ps.push(p.map((v,k)=>v+(q[k]-v)*j/20))});return ps;
  }
  if(name==='crescent'){
   const R=200,r=190,d=40,x=(R*R-r*r+d*d)/(2*d),phi=Math.acos(x/R),alpha=Math.acos((x-d)/r),ps=[];
   for(let i=0;i<=30;i++){const t=phi+(2*Math.PI-2*phi)*i/30;ps.push([700+R*Math.cos(t),310+R*Math.sin(t)])}
   for(let i=1;i<30;i++){const t=-alpha-(2*Math.PI-2*alpha)*i/30;ps.push([700+d+r*Math.cos(t),310+r*Math.sin(t)])}return ps;
  }
  return Array.from({length:60},(_,i)=>{const t=i*Math.PI/30;return[700+190*Math.cos(t),310+190*Math.sin(t)]});
 },
 deform(ps,index,dx,dy){
  // Move a small neighborhood of the boundary. Back off before self-contact
  // so the visible filled polygon and its area centroid describe one sheet.
  for(let f=1;f>=1/256;f/=2){
   const next=ps.map((p,j)=>{const d=Math.min(Math.abs(j-index),ps.length-Math.abs(j-index)),w=Math.exp(-.5*(d/(ps.length*.055))**2)*f;
    return[Math.max(260,Math.min(1220,p[0]+dx*w)),Math.max(105,Math.min(525,p[1]+dy*w))]});
   if(C.valid(next))return next;
  }return ps.map(p=>p.slice());
 }
};
if(typeof module!=='undefined')module.exports=C;g.ClayCore=C;
})(typeof window==='undefined'?globalThis:window);
