// Existing STEAMKit CC0 recordings. Credits: assets/sfx/CREDITS.txt.
(function(){
 const files={page:'./assets/sfx/page.mp3',select:'./assets/sfx/select.mp3',correct:'./assets/sfx/correct.mp3',wrong:'./assets/sfx/wrong.mp3',reveal:'./assets/sfx/fly.mp3',add:'./assets/sfx/tick.mp3'};
 const sounds={},aliases={step:'select',undo:'select',complete:'correct'};let enabled=true;
 for(const [name,src] of Object.entries(files)){const a=new Audio(src);a.preload='auto';a.volume=name==='page'?.38:name==='wrong'?.25:.36;a.dataset.cue=name;a.hidden=true;document.body.append(a);sounds[name]=a;}
 function stop(){for(const a of Object.values(sounds)){a.pause();try{a.currentTime=0}catch{}}}
 function play(kind){stop();if(!enabled)return false;const a=sounds[aliases[kind]||kind];if(!a)return false;try{a.play()?.catch(()=>{});return true}catch{return false}}
 function page(p,last){return play(last?'complete':p.kind==='cover'||p.kind==='chapter'?'reveal':p.model||p.models||p.stages?'select':'page')}
 function setEnabled(value){enabled=!!value;if(!enabled)stop()}
 document.addEventListener('visibilitychange',()=>{if(document.hidden)stop()});
 window.CourseSound={play,page,stop,setEnabled,isEnabled:()=>enabled};
})();
