/* Choose one of two points; each click advances one verification step. */
window.CenterHuntView={mount(root,state,{celebrate,clearCelebration,beep,announce}){
 const C=CenterHuntCore,ns='http://www.w3.org/2000/svg',rest={x:700,y:285,angle:0};let frame=0,motion=null,disposed=false;
 if(state.version!==2)Object.assign(state,C.initial(state.shape||0));
 const icons={reset:'↺',play:'▶',swap:'<svg viewBox="0 0 32 32" aria-hidden="true"><path d="M5 9h5c6 0 6 14 12 14h5m-5-5 5 5-5 5M5 23h5c2 0 3-2 4-4m4-6c1-2 2-4 4-4h5m-5-5 5 5-5 5"/></svg>'};
 const shape=()=>C.shapes[state.shape],center=()=>C.centerOfMass(shape()),reduced=()=>matchMedia('(prefers-reduced-motion: reduce)').matches,path=ps=>'M'+ps.map(p=>p.join(' ')).join('L')+'Z';
 function el(tag,attrs={},text){const n=document.createElementNS(ns,tag);for(const[k,v]of Object.entries(attrs))n.setAttribute(k,v);if(text!==undefined)n.textContent=text;return n;}
 function hint(){if(motion)return ['第一次悬挂…','第二次悬挂…','揭晓重心…'][motion.stage];return state.revealed?'交点就是重心':state.lines.length===2?'点 ▶ 揭晓':state.lines.length===1?'点 ▶ 换个挂点':state.choice?'点 ▶ 验证':'选 A 或 B';}
 function suspension(){return state.revealed?null:motion?motion.stage:state.lines.length?state.lines.length-1:null;}
 function trace(group,id,index){const p=shape().holes[id],c=center(),len=Math.hypot(c[0]-p[0],c[1]-p[1]),dx=(c[0]-p[0])/len,dy=(c[1]-p[1])/len;group.append(el('line',{x1:p[0]-dx*800,y1:p[1]-dy*800,x2:p[0]+dx*800,y2:p[1]+dy*800,class:'hunt-trace',stroke:shape().kind==='zometool'?(index?'#ffb15d':'#78d6ef'):(index?'#cf6920':'#237f9b'),'stroke-width':5,'stroke-dasharray':index?'':'11 7'}));}
 function ui(){
  if(disposed)return;const s=shape(),d=path(s.points),stage=suspension(),locked=!!motion||state.lines.length>0||state.revealed;
  root.classList.add('hunt-ab');root.innerHTML='<svg class="hunt-svg" viewBox="0 0 1400 610" aria-label="'+s.name+'：从A、B两点中选择重心"></svg><div class="hunt-hint" aria-live="polite">'+hint()+(s.kind==='zometool'?'<small class="hunt-mass-note">理想质量示意</small>':'')+'</div><div class="hunt-controls"></div>';
  const svg=root.querySelector('.hunt-svg'),defs=el('defs'),grad=el('linearGradient',{id:'hunt-material',x1:0,y1:0,x2:1,y2:1});grad.append(el('stop',{offset:0,'stop-color':'#fff2d5'}),el('stop',{offset:'.48','stop-color':s.color}),el('stop',{offset:1,'stop-color':s.color}));const clip=el('clipPath',{id:'hunt-clip'});clip.append(el('path',{d}));defs.append(grad,clip);svg.append(defs,el('ellipse',{cx:700,cy:490,rx:210,ry:17,fill:'#111d30',opacity:.4}));
  if(stage!==null&&stage<2){const pin=el('g',{class:'hunt-pin'});pin.append(el('path',{d:'M680 45H720M700 45V75',stroke:'#a6b5c7','stroke-width':3,'stroke-linecap':'round'}),el('circle',{cx:700,cy:75,r:7,fill:'#eef3f4'}));svg.append(pin);}
  const body=el('g',{class:'hunt-body',transform:`translate(${state.pose.x} ${state.pose.y}) rotate(${state.pose.angle})`});svg.append(body);
  if(s.kind==='zometool'){
   const [x,y,width,height]=s.imageBounds;body.append(el('image',{x,y,width,height,href:s.image,class:'hunt-native-model','aria-label':'新拼搭 Zometool 小钥匙：12个连接球、12根短蓝棍'}));
  }else body.append(el('path',{d,transform:'translate(0 8)',fill:'#8c755d',opacity:.8,class:'hunt-depth'}),el('path',{d,fill:'url(#hunt-material)',stroke:'#fff0d4','stroke-width':2,'stroke-linejoin':'round',class:'hunt-board'}));
  if(s.eye)body.append(el('circle',{cx:s.eye[0],cy:s.eye[1],r:6,fill:'#5f5041',class:'hunt-decoration'}));
  const traces=el('g',{'clip-path':'url(#hunt-clip)',class:'hunt-traces'});body.append(traces);state.lines.forEach((id,i)=>trace(traces,id,i));
  if(stage!==null)for(const i of [0,1]){if(i>stage)continue;const p=s.holes[i];body.append(el('circle',{cx:p[0],cy:p[1],r:7,fill:'#25364b',stroke:'#fff0cf','stroke-width':2,class:'hunt-pivot'}));}
  for(const candidate of C.candidates(state.shape)){
   const {label,point}=candidate,selected=state.choice===label,correct=state.revealed&&label===s.answer,wrong=state.revealed&&selected&&!correct;
   const g=el('g',{class:'hunt-candidate'+(selected?' selected':'')+(correct?' correct':wrong?' wrong':''),transform:`translate(${point[0]} ${point[1]})`,role:'button',tabindex:locked?-1:0,'aria-label':'选择'+label+'点','aria-pressed':selected,'aria-disabled':locked,'data-candidate':label});
   g.append(el('circle',{r:31,class:'hunt-candidate-hit'}),el('circle',{r:25,class:'hunt-candidate-ring'}),el('text',{'text-anchor':'middle','dominant-baseline':'central',transform:`rotate(${-state.pose.angle})`,class:'hunt-candidate-label'},label));
   if(correct||wrong){const badge=el('g',{class:'hunt-result-badge',transform:`rotate(${-state.pose.angle}) translate(24 -24)`});badge.append(el('circle',{r:12}),el('text',{'text-anchor':'middle','dominant-baseline':'central'},correct?'✓':'×'));g.append(badge);}
   g.addEventListener('click',()=>choose(label));g.addEventListener('keydown',e=>{if(['Enter',' '].includes(e.key)){e.preventDefault();e.stopPropagation();choose(label)}});body.append(g);
  }
  if(stage!==null&&stage<2){const plumb=el('g',{class:'hunt-plumb'});plumb.append(el('line',{x1:700,y1:75,x2:700,y2:520,stroke:stage?'#f2ac69':'#78d6ef','stroke-width':2,'stroke-dasharray':'4 5'}),el('path',{d:'M700 516l-10 19 10 11 10-11Z',fill:stage?'#f2ac69':'#78d6ef'}));svg.append(plumb);}
  const controls=root.querySelector('.hunt-controls');const add=(name,icon,fn,disabled=false)=>{const b=document.createElement('button');b.className='round';b.setAttribute('aria-label',name);b.title=name;b.innerHTML=icons[icon];b.disabled=disabled;b.onclick=()=>{b.blur();fn()};controls.append(b);return b;};
  const play=add('验证猜想','play',verify,!!motion||!C.canVerify(state));play.classList.add('hunt-verify');
  add('换个造型','swap',()=>restart((state.shape+1)%C.shapes.length));if(state.choice||motion||state.revealed)add('重新猜重心','reset',()=>restart(state.shape));
 }
 function choose(label){if(motion||state.lines.length||state.revealed||!['A','B'].includes(label))return;state.choice=label;beep('select');ui();announce('已选'+label+'点，点击三角形按钮验证。');root.querySelector('[data-candidate="'+label+'"]').focus({preventScroll:true});}
 function pose(p){state.pose=p;root.querySelector('.hunt-body')?.setAttribute('transform',`translate(${p.x} ${p.y}) rotate(${p.angle})`);root.querySelectorAll('.hunt-candidate-label').forEach(t=>t.setAttribute('transform',`rotate(${-p.angle})`));}
 function finish(reward=false){
  if(!motion)return;cancelAnimationFrame(frame);frame=0;const {stage,target,choice}=motion;motion=null;state.pose={...target};
  if(stage<2){state.lines=Array.from({length:stage+1},(_,i)=>i);ui();announce(stage===0?'第一条线已画好，再点击三角形换个挂点。':'第二条线已画好，再点击三角形揭晓。');return;}
  state.verifiedChoice=choice;state.revealed=true;state.solved=choice===shape().answer;ui();announce((state.solved?'猜对了！':'再看一看，')+'重心在'+shape().answer+'点。');if(reward){if(state.solved)celebrate();else beep('reveal');}
 }
 function moveAround(from,to,hole,v){const ease=1-(1-v)**3,p=shape().holes[hole],a=C.world(p,from),b=C.world(p,to),delta=((to.angle-from.angle+540)%360)-180,angle=from.angle+delta*ease,rot=C.world(p,{x:0,y:0,angle});return{x:a[0]+(b[0]-a[0])*ease-rot[0],y:a[1]+(b[1]-a[1])*ease-rot[1],angle};}
 function verify(){
  if(motion||!C.canVerify(state))return;
  const stage=state.lines.length,from={...state.pose},hole=stage===0?0:1,target=stage<2?C.hanging(shape(),shape().holes[hole]):{...rest},p=C.world(shape().holes[hole],from),lift={...from,x:from.x+700-p[0],y:from.y+75-p[1]},duration=stage<2?1500:800;
  motion={choice:state.choice,start:performance.now(),stage,target};beep('step');ui();if(reduced()){finish(true);return;}
  const tick=t=>{if(!motion||disposed)return;const ms=t-motion.start;if(ms>=duration){finish(true);return;}
   const next=stage===2?moveAround(from,target,hole,ms/duration):ms<450?moveAround(from,lift,hole,ms/450):moveAround(lift,target,hole,(ms-450)/(duration-450));pose(next);
   const plumb=root.querySelector('.hunt-plumb');if(plumb)plumb.setAttribute('opacity',ms<450?0:1);frame=requestAnimationFrame(tick);
  };frame=requestAnimationFrame(tick);
 }
 function restart(index){clearCelebration();cancelAnimationFrame(frame);frame=0;motion=null;Object.assign(state,C.initial(index));beep('undo');ui();}
 const stop=()=>finish(false);window.addEventListener('blur',stop);ui();return{stop,destroy(){stop();disposed=true;cancelAnimationFrame(frame);window.removeEventListener('blur',stop);},debug(){return{...JSON.parse(JSON.stringify(state)),phase:C.phase(state),animating:!!motion,verificationStep:suspension(),center:center(),holes:shape().holes.map(p=>C.world(p,state.pose)),worldCenter:C.world(center(),state.pose)};}};
}};
