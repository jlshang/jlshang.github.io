window.COURSE={
  "id": "top-lesson1-20261121",
  "title": "平衡的挑战",
  "minutes": "第一讲 · 约55–65分钟（未试教）",
  "fallback": "./assets/trapezoid.png",
  "pages": [
    {
      "id": "cover",
      "kind": "cover",
      "title": "平衡的挑战",
      "section": "开场",
      "notes": "第一讲：形状、重心位置、高低和改造实践。第二讲再解释旋转与减速。\n配图采用用户2026-11-21提供的透明PNG，保持完整比例；课名为独立文本，叠放在拉起的横幅内，无副标题和小字。\n封面换用用户最后提供的72d5224f图片，课名沿横幅向右上方倾斜10°。",
      "image": "./assets/cover-balance-banner.png",
      "imageAlt": "伙伴们坐在跷跷板上拉起空白横幅"
    },
    {
      "id": "common-tops",
      "kind": "photo",
      "title": "常见的陀螺",
      "section": "开场",
      "notes": "只观察共同点，不提前给结论；点图放大，保留图名。\n【素材署名】木质陀螺：Lacen，Public domain，https://commons.wikimedia.org/wiki/File:Spinning_top.jpg。盘形陀螺：Juni from Kyoto, Japan，CC BY 2.0，https://commons.wikimedia.org/wiki/File:Japanese_top.jpg；许可：https://creativecommons.org/licenses/by/2.0/；裁去外围留白、亮度×1.25。\n对战和金属陀螺来自用户原PPT第2页，仅沿用原教学素材，未核实额外的公开传播许可。\n本轮用macOS Vision离线主体分割、透明PNG等比裁切；无白底框，图名保留。",
      "images": [
        [
          "./assets/common-wood-cutout.png",
          "木质陀螺"
        ],
        [
          "./assets/common-japan-cutout.png",
          "盘形陀螺"
        ],
        [
          "./assets/common-battle-cutout.png",
          "对战陀螺"
        ],
        [
          "./assets/common-metal-cutout.png",
          "金属陀螺"
        ]
      ],
      "imageLayout": "four-cutouts"
    },
    {
      "id": "round-predict",
      "kind": "predict",
      "title": "陀螺一定是圆形吗？",
      "section": "开场",
      "notes": "A是、B不是，只投票不判对错。每点一次记一票；减号撤最近一票，重来清零。卡通图由用户指定的jimeng.mathufo.com生成。\n卡通造型按原图配色制作3D展示，绕自身竖轴旋转，不作为实验模拟；右下可暂停。",
      "options": [
        "是",
        "不是"
      ],
      "vote": true,
      "optionLayout": "cards",
      "cartoonSpin": true
    },
    {
      "id": "part-shape",
      "kind": "chapter",
      "title": "探索陀螺的形状",
      "section": "01 探索陀螺的形状",
      "notes": "请孩子先观察、提出猜想，再动手验证。未实搭、未试教。\n配图为用户2026-11-21指定的透明PNG，保持完整比例，不加白底卡片。",
      "number": "01",
      "titleLines": [
        "探索",
        "陀螺的形状"
      ],
      "image": "./assets/chapter01-top-shapes.png",
      "imageAlt": "伙伴们观察圆形、方形和星形陀螺"
    },
    {
      "id": "shape-select",
      "kind": "observe",
      "title": "你想先搭哪一个？",
      "section": "01 探索陀螺的形状",
      "notes": "直接点击一个俯视造型进入拼搭，随后依次搭另外两个。Tab和回车也可选择。无名称标签，图形本身是选择入口。",
      "models": [
        [
          "diamond",
          "红杆菱形"
        ],
        [
          "trapezoid",
          "等腰梯形"
        ],
        [
          "fan",
          "旋转扇面"
        ]
      ],
      "selectBuild": true,
      "defaultView": "top",
      "hideModelNames": true
    },
    {
      "id": "diamond-build",
      "kind": "build",
      "title": "拼搭：红杆菱形",
      "section": "01 探索陀螺的形状",
      "notes": "＋按一个结构单元增加，−撤回。保持同一镜头与比例。请先查看材料：红菱形4中红围边、2短红及2中黄连中心；梯形上下底用中蓝和短蓝，两腰短黄，中心接2短蓝和2短黄；扇面每片2短蓝、2短绿。四片必须同向。原生模型是依据原图意图合法重构，未宣称逐杆恢复照片。",
      "buildFor": "diamond",
      "stages": [
        {
          "model": "diamond-start",
          "label": "先连两条边"
        },
        {
          "model": "diamond-rim",
          "label": "围好外框"
        },
        {
          "model": "diamond-body",
          "label": "连接中心球"
        }
      ],
      "top": true,
      "defaultView": "top"
    },
    {
      "id": "diamond-axis",
      "kind": "build",
      "title": "装好转杆，再检查",
      "section": "01 探索陀螺的形状",
      "notes": "转杆上方中蓝、下方短蓝，顶部和最下端都加球，底部小球接触桌面。手轻捻转杆，不甩动、不向人投掷。梯形为统一轴类型采用蓝轴，原图红轴不照搬。完成后仍需点击底栏下一页，不自动跳。",
      "buildFor": "diamond",
      "stages": [
        {
          "model": "diamond-body",
          "label": "检查转面"
        },
        {
          "model": "diamond",
          "label": "装上转杆"
        }
      ],
      "top": true,
      "defaultView": "front"
    },
    {
      "id": "trapezoid-build",
      "kind": "build",
      "title": "拼搭：等腰梯形",
      "section": "01 探索陀螺的形状",
      "notes": "＋按一个结构单元增加，−撤回。保持同一镜头与比例。请先查看材料：红菱形4中红围边、2短红及2中黄连中心；梯形上下底用中蓝和短蓝，两腰短黄，中心接2短蓝和2短黄；扇面每片2短蓝、2短绿。四片必须同向。原生模型是依据原图意图合法重构，未宣称逐杆恢复照片。",
      "buildFor": "trapezoid",
      "stages": [
        {
          "model": "trapezoid-start",
          "label": "先连两条边"
        },
        {
          "model": "trapezoid-rim",
          "label": "围好外框"
        },
        {
          "model": "trapezoid-body",
          "label": "连接中心球"
        }
      ],
      "top": true,
      "defaultView": "top"
    },
    {
      "id": "trapezoid-axis",
      "kind": "build",
      "title": "装好转杆，再检查",
      "section": "01 探索陀螺的形状",
      "notes": "转杆上方中蓝、下方短蓝，顶部和最下端都加球，底部小球接触桌面。手轻捻转杆，不甩动、不向人投掷。梯形为统一轴类型采用蓝轴，原图红轴不照搬。完成后仍需点击底栏下一页，不自动跳。",
      "buildFor": "trapezoid",
      "stages": [
        {
          "model": "trapezoid-body",
          "label": "检查转面"
        },
        {
          "model": "trapezoid",
          "label": "装上转杆"
        }
      ],
      "top": true,
      "defaultView": "front"
    },
    {
      "id": "fan-build",
      "kind": "build",
      "title": "拼搭：旋转扇面",
      "section": "01 探索陀螺的形状",
      "notes": "＋按一个结构单元增加，−撤回。保持同一镜头与比例。请先查看材料：红菱形4中红围边、2短红及2中黄连中心；梯形上下底用中蓝和短蓝，两腰短黄，中心接2短蓝和2短黄；扇面每片2短蓝、2短绿。四片必须同向。原生模型是依据原图意图合法重构，未宣称逐杆恢复照片。",
      "buildFor": "fan",
      "stages": [
        {
          "model": "fan-blade-0",
          "label": "从中心球开始"
        },
        {
          "model": "fan-blade-1",
          "label": "搭好一片扇叶"
        },
        {
          "model": "fan-blade-2",
          "label": "添第二片"
        },
        {
          "model": "fan-blade-3",
          "label": "添第三片"
        },
        {
          "model": "fan-blade-4",
          "label": "四片同向扇叶"
        }
      ],
      "top": true,
      "defaultView": "top"
    },
    {
      "id": "fan-axis",
      "kind": "build",
      "title": "装好转杆，再检查",
      "section": "01 探索陀螺的形状",
      "notes": "转杆上方中蓝、下方短蓝，顶部和最下端都加球，底部小球接触桌面。手轻捻转杆，不甩动、不向人投掷。梯形为统一轴类型采用蓝轴，原图红轴不照搬。完成后仍需点击底栏下一页，不自动跳。",
      "buildFor": "fan",
      "stages": [
        {
          "model": "fan-blade-4",
          "label": "检查转面"
        },
        {
          "model": "fan",
          "label": "装上转杆"
        }
      ],
      "top": true,
      "defaultView": "front"
    },
    {
      "id": "spin-compare",
      "kind": "observe",
      "title": "平衡的挑战",
      "section": "01 探索陀螺的形状",
      "notes": "点击右下眼睛，一次显示三款当前装配的平衡判断：菱形✓、梯形×、旋转扇面✓；再次点击隐藏。不需要逐一选勾叉，不显示重心、轴心或文字注解。此处是本课这三个具体模型装配下的配平示意，与后续理想重心对轴分析对应；不是实测旋转记录，更不是“所有梯形绝对不能转”的结论。实际旋转时长与稳定性仍需实物验证。",
      "models": [
        [
          "diamond",
          "红杆菱形"
        ],
        [
          "trapezoid",
          "等腰梯形"
        ],
        [
          "fan",
          "旋转扇面"
        ]
      ],
      "resultMode": "balance",
      "hideModelNames": true,
      "defaultView": "top",
      "balanceResults": {
        "diamond": true,
        "trapezoid": false,
        "fan": true
      }
    },
    {
      "id": "shape-findings",
      "kind": "wall",
      "title": "怎样的转面更容易平衡？",
      "section": "01 探索陀螺的形状",
      "notes": "标准答案墙保留预设及自由输入。仅完整匹配“旋转对称更容易平衡”这条观点首次贴上墙时撒花；其他观点只收集，不撒花，不按模糊关键词判分。重复同一观点仍计数，不反复庆祝；回翻不重播，重来清空。强调对应材料质量一致时旋转对称便于配平，不将其说成能够旋转的唯一必要条件。",
      "wallLayout": "survey",
      "prompts": [
        "有轴对称就够了",
        "旋转对称更容易平衡",
        "必须两种对称都有"
      ],
      "largeHorizontal": true,
      "celebrateAnswer": "旋转对称更容易平衡"
    },
    {
      "id": "part-center",
      "kind": "chapter",
      "title": "旋转的秘密",
      "section": "02 旋转的秘密",
      "notes": "请孩子先观察、提出猜想，再动手验证。未实搭、未试教。\n配图采用用户2026-11-21提供的透明PNG，保持完整比例；沿用统一左侧编号/标题、右侧配图布局；编号240px，标题80px。",
      "number": "02",
      "titleLines": [
        "旋转的秘密"
      ],
      "image": "./assets/chapter02-rotating-friends.png",
      "imageAlt": "黄色伙伴和绿色伙伴一起旋转"
    },
    {
      "id": "center-intro",
      "kind": "balance",
      "title": "找到它的平衡点：重心",
      "section": "02 旋转的秘密",
      "notes": "左右原有各3球及球在横杆上的局部位置不变，三角支架固定。手动加球时，横杆连同小球一起向较重侧倾斜，数量相同恢复水平；黄色重心同时依据全部小球的位置移动。每侧最多另加4球，减号只撤新增球。右下播放自动演示，离页、目录、备注、后台停止。该图为等重球和理想固定枢轴的定性倾斜示意：角度限制±14度用来表达偏重方向，不是计算自由天平真实稳定角度或称量读数；忽略横杆质量。黄点明确标为小球整体重心，不是支架的支点；两侧等重表示横向居中，球堆上移时整体重心也会上移，可以位于物体之间的空处。说明仅放教师备注，不在画面增加小字。"
    },
    {
      "id": "center-point",
      "kind": "observe",
      "title": "重心在转杆上吗？",
      "section": "02 旋转的秘密",
      "notes": "点眼睛显示由球和杆共同计算的重心点，白线是转轴。这里采用理想质量示意：每球质量1，杆质量按长度×0.10，杆重置于端点中点；弯绿杆也用中点近似。不称量不声称这是实物精确重心，需实测配平。重心点不一定在中心球处。\n同材质且零件绕转轴旋转对应时，重心落在轴上；当前梯形略偏轴。不能反推所有非旋转对称造型都偏轴。黄色靶标中心是计算值；青色十字为转轴；标签只用引线，绝不移动重心位置来夸大差异。 当前梯形理想重心本地[7.175925656,0,-0.221651913]，其转轴为本地x轴，偏心距0.221651913模型坐标单位，不是厘米。黄色点不人为外移；俯视局部放大仅用于看清它与轴心的距离。\n【教师解释】旋转对应的位置一样重，重心就在转杆上。说明移入备注，不在学生画面增加橙色小字。",
      "massToggle": true,
      "top": true,
      "models": [
        [
          "diamond",
          ""
        ],
        [
          "trapezoid",
          ""
        ],
        [
          "fan",
          ""
        ]
      ],
      "modelOptions": {"diamond": {"frameOverride": 13.333333333333334}, "trapezoid": {"frameOverride": 13.333333333333334}, "fan": {"frameOverride": 15.833333333333334}},
      "hideModelNames": true,
      "defaultView": "top"
    },
    {
      "id": "center-shift",
      "kind": "build",
      "title": "减少扇叶，重心会怎样？",
      "section": "02 旋转的秘密",
      "notes": "初态显示四片完整扇叶与位于转轴上的理想重心。减号每次移除一整片：四瓣→三瓣→两瓣，第二次移除的是与第一片相邻的扇叶；黄色重心按剩余实际球杆的理想质量计算连续更新。保留杆位、轴杆、底端、相机和尺度。加号逐片补回，重来恢复四瓣；离页返回保留进度。不是移动图形冒充重心变化。质量假设为每球1、杆按长度×0.10，未称量实物。",
      "stages": [
        {
          "model": "fan-high",
          "label": "完整四瓣，重心在转轴上"
        },
        {
          "model": "fan-missing",
          "label": "移除一瓣，观察重心偏移"
        },
        {
          "model": "fan-two-missing",
          "label": "再移除相邻一瓣，再观察重心"
        }
      ],
      "massToggle": true,
      "top": true,
      "defaultView": "top",
      "massInitially": true,
      "buildAction": "remove"
    },
    {
      "id": "height-compare",
      "kind": "observe",
      "title": "哪一个重心更低？",
      "section": "02 旋转的秘密",
      "notes": "同样零件、同轴总长、同底端支点，正面同尺度比较。先选择重心更低的造型：低档显示绿勾并首次撒花；高档红叉、不撒花。右下标签图标在选中低档后可用，点击后以标准盖章动画显示“更稳定”，替换该处绿勾；再次点击可隐藏。切换到高档清除印章；回翻保留但不重播，重来清空。此章用于同组可比条件下的课堂稳定性讨论，不是任何转速、摩擦、惯量条件下均更稳定或转得更久的定律；仍应结合实物试转。",
      "models": [
        [
          "fan",
          "低档"
        ],
        [
          "fan-high",
          "高档"
        ]
      ],
      "massToggle": true,
      "ground": true,
      "top": false,
      "defaultView": "front",
      "resultMode": "choice",
      "massInitially": true,
      "correctModel": "fan",
      "hideModelNames": true,
      "choiceStamp": "更稳定"
    },
    {
      "id": "part-repair",
      "kind": "chapter",
      "title": "炫酷陀螺",
      "section": "03 炫酷陀螺",
      "notes": "请孩子先观察、提出猜想，再动手验证。未实搭、未试教。\n配图为用户2026-11-21指定的透明PNG，保持完整比例，不加白底卡片。",
      "number": "03",
      "titleLines": [
        "炫酷陀螺"
      ],
      "image": "./assets/chapter03-top-workshop.png",
      "imageAlt": "伙伴们一起动手改造陀螺"
    },
    {
      "id": "repair-observe",
      "kind": "observe",
      "title": "这只陀螺，怎样改得更平衡？",
      "section": "03 炫酷陀螺",
      "notes": "起点沿原PPT五向红棍造型改为缺一根辐条、转面偏高：四根短红辐条，上短红、下中红轴，上下端小球保留。先观察不对称，后面连续补齐、降转面、再装饰。不提前展示全部改造答案。 学生画面不再显示重心标记，也不提供重心显隐按钮，直接观察并继续改造；以上重心解释仅供教师参考。 首次入场使用斜视，显示转杆及全部球棍，不从俯视开始；仍不显示重心。",
      "model": "upgrade-missing-high",
      "top": true,
      "defaultView": "home",
      "frameOverride": 14,
      "massToggle": false,
      "massInitially": false
    },
    {
      "id": "repair-balance",
      "kind": "build",
      "title": "补上这一根，让转面对称",
      "section": "03 炫酷陀螺",
      "notes": "保留旧球棍位置和相机，＋仅补缺失的短红辐条。补齐以后恢复五重旋转对称，理想重心回到转轴上，−可撤回。 学生画面不再显示重心标记，也不提供重心显隐按钮，直接观察并继续改造；以上重心解释仅供教师参考。",
      "stages": [
        {
          "model": "upgrade-missing-high",
          "label": "四根辐条，缺一根"
        },
        {
          "model": "upgrade-red-high",
          "label": "补回第五根，恢复旋转对称"
        }
      ],
      "massToggle": false,
      "defaultView": "top",
      "frameOverride": 14,
      "massInitially": false
    },
    {
      "id": "repair-height",
      "kind": "build",
      "title": "把转面降下来",
      "section": "03 炫酷陀螺",
      "notes": "只交换上短红/下中红为上中红/下短红，转面、球数、杆数、总轴长和底部支点不变。正面同尺度显示转面下降、理想重心降低。不是承诺任何启动条件下都更久，需要实测是否擦地及稳定程度。 学生画面不再显示重心标记，也不提供重心显隐按钮，直接观察并继续改造；以上重心解释仅供教师参考。",
      "stages": [
        {
          "model": "upgrade-red-high",
          "label": "完整对称，但转面偏高"
        },
        {
          "model": "upgrade-red",
          "label": "交换上下轴杆，降低转面"
        }
      ],
      "massToggle": false,
      "defaultView": "front",
      "frameOverride": 14,
      "massInitially": false,
      "ground": true
    },
    {
      "id": "repair-pattern",
      "kind": "build",
      "title": "保持平衡，再变得炫酷",
      "section": "03 炫酷陀螺",
      "notes": "从已对称且降低的红杆转面继续，不换造型。前四状态依次加五根中黄、外端球和星形外框。再加三组：下层五根短红和球；下层五根中黄和球；下层十根短黄连接外框。每次在五个旋转对应位置同时添加，原有球杆和底端支点不变。新三组在下方增加对称质量，理想小球/杆质量计算的重心逐步降低、仍在转轴上；原生孔向与杆长逐一验证。默认斜视可看见下层，俯视按钮检查五向对称。角度、颜色不代表真实旋转时长；尚未实搭试转。 学生画面不再显示重心标记，也不提供重心显隐按钮，直接观察并继续改造；以上重心解释仅供教师参考。 完成最后一组拼搭时首次撒花；入场、回翻、重复点击不重播；重来后可重新完成并庆祝。",
      "stages": [
        {
          "model": "upgrade-red",
          "label": "保留对称的低转面"
        },
        {
          "model": "upgrade-rays",
          "label": "五处对应位置一起加黄棍"
        },
        {
          "model": "upgrade-balls",
          "label": "对应的外端一起加球"
        },
        {
          "model": "upgrade-rim",
          "label": "连起星形外框"
        },
        {
          "model": "upgrade-lower-red",
          "label": "五个对应位置加下层红棍和球"
        },
        {
          "model": "upgrade-lower-rays",
          "label": "下层五处同时加黄棍和球"
        },
        {
          "model": "upgrade-lower-rim",
          "label": "连好下层星框，保留五向对称"
        }
      ],
      "massToggle": false,
      "top": true,
      "frameOverride": 17,
      "defaultView": "home",
      "massInitially": false,
      "celebrateComplete": true
    },
    {
      "id": "homework-tops",
      "kind": "observe",
      "title": "课后挑战：拼搭以下陀螺，试试旋转的平衡性",
      "section": "课后挑战",
      "models": [
        [
          "tri-cyclone",
          "三翼旋风"
        ],
        [
          "star-gear",
          "星芒齿轮"
        ]
      ],
      "defaultView": "home",
      "notes": "课后挑战分两页，每页两个原生造型。全组依球杆总数从少到多：三翼旋风→星芒齿轮→钻晶皇冠→双环飞碟；造型下方保留四字名称。第一次进入本页采用标准1700ms半周旋转、轻微拉近后停稳；返回已看过页面不重复播放，直接打开本页也有入场。拖动、回正面、离页、目录、备注、后台或减少动态会结束入场，不妨碍操作。不作真实试转仿真，稳定性需实物试验。",
      "entrance": "spin"
    },
    {
      "id": "homework-tops-2",
      "kind": "observe",
      "title": "课后挑战：拼搭以下陀螺，试试旋转的平衡性",
      "section": "课后挑战",
      "models": [
        [
          "crystal-crown",
          "钻晶皇冠"
        ],
        [
          "double-saucer",
          "双环飞碟"
        ]
      ],
      "defaultView": "home",
      "notes": "课后挑战分两页，每页两个原生造型。全组依球杆总数从少到多：三翼旋风→星芒齿轮→钻晶皇冠→双环飞碟；造型下方保留四字名称。第一次进入本页采用标准1700ms半周旋转、轻微拉近后停稳；返回已看过页面不重复播放，直接打开本页也有入场。拖动、回正面、离页、目录、备注、后台或减少动态会结束入场，不妨碍操作。不作真实试转仿真，稳定性需实物试验。",
      "entrance": "spin"
    }
  ],
  "legacyEntries": [
    "转不倒的陀螺_互动课件.html"
  ]
};
