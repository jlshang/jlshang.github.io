window.COURSE={
  "id": "top-lesson1-20261121",
  "title": "平衡的挑战",
  "minutes": "第一讲 · 约55–65分钟（未试教）",
  "fallback": "./assets/trapezoid.png",
  "pages": [
    {
      "id": "cover",
      "kind": "cover",
      "title": "平衡的挑战",
      "section": "开场",
      "notes": "第一讲：形状、重心位置、高低和改造实践。第二讲再解释旋转与减速。\n配图采用用户2026-11-21提供的透明PNG，保持完整比例；课名为独立文本，叠放在拉起的横幅内，无副标题和小字。\n封面换用用户最后提供的72d5224f图片，课名沿横幅向右上方倾斜10°。",
      "image": "./assets/cover-balance-banner.png",
      "imageAlt": "伙伴们坐在跷跷板上拉起空白横幅"
    },
    {
      "id": "common-tops",
      "kind": "photo",
      "title": "常见的陀螺",
      "section": "开场",
      "notes": "只观察共同点，不提前给结论；点图放大，保留图名。\n【素材署名】木质陀螺：Lacen，Public domain，https://commons.wikimedia.org/wiki/File:Spinning_top.jpg。盘形陀螺：Juni from Kyoto, Japan，CC BY 2.0，https://commons.wikimedia.org/wiki/File:Japanese_top.jpg；许可：https://creativecommons.org/licenses/by/2.0/；裁去外围留白、亮度×1.25。\n对战和金属陀螺来自用户原PPT第2页，仅沿用原教学素材，未核实额外的公开传播许可。\n本轮用macOS Vision离线主体分割、透明PNG等比裁切；无白底框，图名保留。",
      "images": [
        [
          "./assets/common-wood-cutout.png",
          "木质陀螺"
        ],
        [
          "./assets/common-japan-cutout.png",
          "盘形陀螺"
        ],
        [
          "./assets/common-battle-cutout.png",
          "对战陀螺"
        ],
        [
          "./assets/common-metal-cutout.png",
          "金属陀螺"
        ]
      ],
      "imageLayout": "four-cutouts"
    },
    {
      "id": "round-predict",
      "kind": "predict",
      "title": "陀螺一定是圆形吗？",
      "section": "开场",
      "notes": "A是、B不是，只投票不判对错。每点一次记一票；减号撤最近一票，重来清零。卡通图由用户指定的jimeng.mathufo.com生成。\n卡通造型按原图配色制作3D展示，绕自身竖轴旋转，不作为实验模拟；右下可暂停。",
      "options": [
        "是",
        "不是"
      ],
      "vote": true,
      "optionLayout": "cards",
      "cartoonSpin": true
    },
    {
      "id": "part-shape",
      "kind": "chapter",
      "title": "探索陀螺的形状",
      "section": "01 探索陀螺的形状",
      "notes": "请孩子先观察、提出猜想，再动手验证。未实搭、未试教。\n配图为用户2026-11-21指定的透明PNG，保持完整比例，不加白底卡片。",
      "number": "01",
      "titleLines": [
        "探索",
        "陀螺的形状"
      ],
      "image": "./assets/chapter01-top-shapes.png",
      "imageAlt": "伙伴们观察圆形、方形和星形陀螺"
    },
    {
      "id": "shape-select",
      "kind": "observe",
      "title": "你想先搭哪一个？",
      "section": "01 探索陀螺的形状",
      "notes": "直接点击一个俯视造型进入拼搭，随后依次搭另外两个。Tab和回车也可选择。无名称标签，图形本身是选择入口。",
      "models": [
        [
          "diamond",
          "红杆菱形"
        ],
        [
          "trapezoid",
          "等腰梯形"
        ],
        [
          "fan",
          "旋转扇面"
        ]
      ],
      "selectBuild": true,
      "defaultView": "top",
      "hideModelNames": true
    },
    {
      "id": "diamond-build",
      "kind": "build",
      "title": "拼搭：红杆菱形",
      "section": "01 探索陀螺的形状",
      "notes": "＋按一个结构单元增加，−撤回。保持同一镜头与比例。请先查看材料：红菱形4中红围边、2短红及2中黄连中心；梯形上下底用中蓝和短蓝，两腰短黄，中心接2短蓝和2短黄；扇面每片2短蓝、2短绿。四片必须同向。原生模型是依据原图意图合法重构，未宣称逐杆恢复照片。",
      "buildFor": "diamond",
      "stages": [
        {
          "model": "diamond-start",
          "label": "先连两条边"
        },
        {
          "model": "diamond-rim",
          "label": "围好外框"
        },
        {
          "model": "diamond-body",
          "label": "连接中心球"
        }
      ],
      "top": true,
      "defaultView": "top"
    },
    {
      "id": "diamond-axis",
      "kind": "build",
      "title": "装好转杆，再检查",
      "section": "01 探索陀螺的形状",
      "notes": "转杆上方中蓝、下方短蓝，顶部和最下端都加球，底部小球接触桌面。手轻捻转杆，不甩动、不向人投掷。梯形为统一轴类型采用蓝轴，原图红轴不照搬。完成后仍需点击底栏下一页，不自动跳。",
      "buildFor": "diamond",
      "stages": [
        {
          "model": "diamond-body",
          "label": "检查转面"
        },
        {
          "model": "diamond",
          "label": "装上转杆"
        }
      ],
      "top": true,
      "defaultView": "front"
    },
    {
      "id": "trapezoid-build",
      "kind": "build",
      "title": "拼搭：等腰梯形",
      "section": "01 探索陀螺的形状",
      "notes": "＋按一个结构单元增加，−撤回。保持同一镜头与比例。请先查看材料：红菱形4中红围边、2短红及2中黄连中心；梯形上下底用中蓝和短蓝，两腰短黄，中心接2短蓝和2短黄；扇面每片2短蓝、2短绿。四片必须同向。原生模型是依据原图意图合法重构，未宣称逐杆恢复照片。",
      "buildFor": "trapezoid",
      "stages": [
        {
          "model": "trapezoid-start",
          "label": "先连两条边"
        },
        {
          "model": "trapezoid-rim",
          "label": "围好外框"
        },
        {
          "model": "trapezoid-body",
          "label": "连接中心球"
        }
      ],
      "top": true,
      "defaultView": "top"
    },
    {
      "id": "trapezoid-axis",
      "kind": "build",
      "title": "装好转杆，再检查",
      "section": "01 探索陀螺的形状",
      "notes": "转杆上方中蓝、下方短蓝，顶部和最下端都加球，底部小球接触桌面。手轻捻转杆，不甩动、不向人投掷。梯形为统一轴类型采用蓝轴，原图红轴不照搬。完成后仍需点击底栏下一页，不自动跳。",
      "buildFor": "trapezoid",
      "stages": [
        {
          "model": "trapezoid-body",
          "label": "检查转面"
        },
        {
          "model": "trapezoid",
          "label": "装上转杆"
        }
      ],
      "top": true,
      "defaultView": "front"
    },
    {
      "id": "fan-build",
      "kind": "build",
      "title": "拼搭：旋转扇面",
      "section": "01 探索陀螺的形状",
      "notes": "＋按一个结构单元增加，−撤回。保持同一镜头与比例。请先查看材料：红菱形4中红围边、2短红及2中黄连中心；梯形上下底用中蓝和短蓝，两腰短黄，中心接2短蓝和2短黄；扇面每片2短蓝、2短绿。四片必须同向。原生模型是依据原图意图合法重构，未宣称逐杆恢复照片。",
      "buildFor": "fan",
      "stages": [
        {
          "model": "fan-blade-0",
          "label": "从中心球开始"
        },
        {
          "model": "fan-blade-1",
          "label": "搭好一片扇叶"
        },
        {
          "model": "fan-blade-2",
          "label": "添第二片"
        },
        {
          "model": "fan-blade-3",
          "label": "添第三片"
        },
        {
          "model": "fan-blade-4",
          "label": "四片同向扇叶"
        }
      ],
      "top": true,
      "defaultView": "top"
    },
    {
      "id": "fan-axis",
      "kind": "build",
      "title": "装好转杆，再检查",
      "section": "01 探索陀螺的形状",
      "notes": "转杆上方中蓝、下方短蓝，顶部和最下端都加球，底部小球接触桌面。手轻捻转杆，不甩动、不向人投掷。梯形为统一轴类型采用蓝轴，原图红轴不照搬。完成后仍需点击底栏下一页，不自动跳。",
      "buildFor": "fan",
      "stages": [
        {
          "model": "fan-blade-4",
          "label": "检查转面"
        },
        {
          "model": "fan",
          "label": "装上转杆"
        }
      ],
      "top": true,
      "defaultView": "front"
    },
    {
      "id": "spin-compare",
      "kind": "observe",
      "title": "平衡的挑战",
      "section": "01 探索陀螺的形状",
      "notes": "本页没有试转模拟，不能把偏心等同于绝对不能转。眼睛揭示的是当前理想模型的轴心/重心关系：菱形与扇面✓“重心在转轴上”，梯形×“重心偏离转轴”；这是球=1、杆=长度×0.1的计算结果，不是实物转动的测量。梯形真实偏移约0.222模型坐标单位，以俯视局部放大呈现，不夸大主图点位。旋转表现仍需实测。",
      "models": [
        [
          "diamond",
          "红杆菱形"
        ],
        [
          "trapezoid",
          "等腰梯形"
        ],
        [
          "fan",
          "旋转扇面"
        ]
      ],
      "resultMode": "alignment",
      "hideModelNames": true,
      "defaultView": "top"
    },
    {
      "id": "shape-findings",
      "kind": "wall",
      "title": "怎样的转面更容易平衡？",
      "section": "01 探索陀螺的形状",
      "notes": "先收集观点，不根据关键词判自由文本。教师核对本次实测证据后，点眼睛揭晓并一次撒花。旋转对称帮助配平，但不是所有陀螺能转的必要条件。反例：不对称薄片也可将轴安在质心。 本轮贴纸改为左图标、右大字单行；备用选项也一条一行。",
      "wallLayout": "survey",
      "prompts": [
        "有轴对称就够了",
        "旋转对称更容易配平",
        "必须两种对称都有"
      ],
      "reveal": "转杆周围，分布要平衡",
      "stamp": false,
      "celebrate": true,
      "largeHorizontal": true
    },
    {
      "id": "part-center",
      "kind": "chapter",
      "title": "旋转的秘密",
      "section": "02 旋转的秘密",
      "notes": "请孩子先观察、提出猜想，再动手验证。未实搭、未试教。\n配图采用用户2026-11-21提供的透明PNG，保持完整比例；沿用统一左侧编号/标题、右侧配图布局；编号240px，标题80px。",
      "number": "02",
      "titleLines": [
        "旋转的秘密"
      ],
      "image": "./assets/chapter02-rotating-friends.png",
      "imageAlt": "黄色伙伴和绿色伙伴一起旋转"
    },
    {
      "id": "center-intro",
      "kind": "balance",
      "title": "找到它的平衡点",
      "section": "02 旋转的秘密",
      "notes": "原有左右各3颗球、横杆与三角支架固定。左右＋各在本侧加一颗等重球，最多另加4颗；−只撤新增球。黄色标记显示小球系统重心的左右位置，按实际数量加权计算；不是固定支架上跷跷板的真实受力模拟。原球绝不移走或重新排列。右下▶自动演示右加两颗、左补两颗、再依次撤回；可暂停，离页/目录/备注/后台自动停止。眼睛显隐重心；重来回到3对3，刷新清空。忽略横杆质量，只比较水平方向重心投影。"
    },
    {
      "id": "center-point",
      "kind": "observe",
      "title": "重心在转杆上吗？",
      "massExplanation": "旋转对应的位置一样重，重心就在转杆上",
      "section": "02 旋转的秘密",
      "notes": "点眼睛显示由球和杆共同计算的重心点，白线是转轴。这里采用理想质量示意：每球质量1，杆质量按长度×0.10，杆重置于端点中点；弯绿杆也用中点近似。不称量不声称这是实物精确重心，需实测配平。重心点不一定在中心球处。\n同材质且零件绕转轴旋转对应时，重心落在轴上；当前梯形略偏轴。不能反推所有非旋转对称造型都偏轴。黄色靶标中心是计算值；青色十字为转轴；标签只用引线，绝不移动重心位置来夸大差异。 当前梯形理想重心本地[7.175925656,0,-0.221651913]，其转轴为本地x轴，偏心距0.221651913模型坐标单位，不是厘米。黄色点不人为外移；俯视局部放大仅用于看清它与轴心的距离。",
      "massToggle": true,
      "top": true,
      "models": [
        [
          "diamond",
          ""
        ],
        [
          "trapezoid",
          ""
        ],
        [
          "fan",
          ""
        ]
      ],
      "hideModelNames": true,
      "defaultView": "top"
    },
    {
      "id": "center-shift",
      "kind": "build",
      "title": "只少一片，会发生什么？",
      "section": "02 旋转的秘密",
      "notes": "眼睛显示计算重心，＋补回同向扇叶，−撤回。重心位置随真实零件集合重算，不用美术点假装。比较的是同一模型缺片/完整两态，不声称一切非旋转对称都会偏心。",
      "stages": [
        {
          "model": "fan-missing",
          "label": "少了一片"
        },
        {
          "model": "fan-high",
          "label": "补回同一片"
        }
      ],
      "massToggle": true,
      "top": true,
      "defaultView": "top",
      "massInitially": true
    },
    {
      "id": "height-compare",
      "kind": "observe",
      "title": "重心的高低有影响吗？",
      "section": "02 旋转的秘密",
      "notes": "两档同零件、同轴总长、同底部小球支点，默认正面同尺度；先实物实验。直接点本次转得更久的造型，立即在其下方盖“转得久”章；再点另一件即可改选，重复点已选件取消。无播放按钮、无两个对勾、无二次确认；重来可清空，不预设哪档赢。",
      "models": [
        [
          "fan",
          "低档"
        ],
        [
          "fan-high",
          "高档"
        ]
      ],
      "massToggle": true,
      "ground": true,
      "top": false,
      "defaultView": "front",
      "resultMode": "winner",
      "massInitially": true,
      "directWinner": true
    },
    {
      "id": "part-repair",
      "kind": "chapter",
      "title": "炫酷陀螺",
      "section": "03 炫酷陀螺",
      "notes": "请孩子先观察、提出猜想，再动手验证。未实搭、未试教。\n配图为用户2026-11-21指定的透明PNG，保持完整比例，不加白底卡片。",
      "number": "03",
      "titleLines": [
        "炫酷陀螺"
      ],
      "image": "./assets/chapter03-top-workshop.png",
      "imageAlt": "伙伴们一起动手改造陀螺"
    },
    {
      "id": "repair-observe",
      "kind": "observe",
      "title": "这只陀螺，怎样改得更平衡？",
      "section": "03 炫酷陀螺",
      "notes": "起点沿原PPT五向红棍造型改为缺一根辐条、转面偏高：四根短红辐条，上短红、下中红轴，上下端小球保留。先观察不对称，后面连续补齐、降转面、再装饰。不提前展示全部改造答案。",
      "model": "upgrade-missing-high",
      "top": true,
      "defaultView": "top",
      "frameOverride": 14,
      "massToggle": true,
      "massInitially": true
    },
    {
      "id": "repair-balance",
      "kind": "build",
      "title": "补上这一根，让转面对称",
      "section": "03 炫酷陀螺",
      "notes": "保留旧球棍位置和相机，＋仅补缺失的短红辐条。补齐以后恢复五重旋转对称，理想重心回到转轴上，−可撤回。",
      "stages": [
        {
          "model": "upgrade-missing-high",
          "label": "四根辐条，缺一根"
        },
        {
          "model": "upgrade-red-high",
          "label": "补回第五根，恢复旋转对称"
        }
      ],
      "massToggle": true,
      "defaultView": "top",
      "frameOverride": 14,
      "massInitially": true
    },
    {
      "id": "repair-height",
      "kind": "build",
      "title": "把转面降下来",
      "section": "03 炫酷陀螺",
      "notes": "只交换上短红/下中红为上中红/下短红，转面、球数、杆数、总轴长和底部支点不变。正面同尺度显示转面下降、理想重心降低。不是承诺任何启动条件下都更久，需要实测是否擦地及稳定程度。",
      "stages": [
        {
          "model": "upgrade-red-high",
          "label": "完整对称，但转面偏高"
        },
        {
          "model": "upgrade-red",
          "label": "交换上下轴杆，降低转面"
        }
      ],
      "massToggle": true,
      "defaultView": "front",
      "frameOverride": 14,
      "massInitially": true,
      "ground": true
    },
    {
      "id": "repair-pattern",
      "kind": "build",
      "title": "保持平衡，再变得炫酷",
      "section": "03 炫酷陀螺",
      "notes": "从刚改好的对称低转面继续。依次在五个对应位置加中黄、外端加球、用短黄连外框，确保旋转对应位置的零件一致。原生杆长孔向有效，不跳换成另一款陀螺。",
      "stages": [
        {
          "model": "upgrade-red",
          "label": "保留对称的低转面"
        },
        {
          "model": "upgrade-rays",
          "label": "五处对应位置一起加黄棍"
        },
        {
          "model": "upgrade-balls",
          "label": "对应的外端一起加球"
        },
        {
          "model": "upgrade-rim",
          "label": "连起星形外框"
        }
      ],
      "massToggle": false,
      "top": true,
      "frameOverride": 14,
      "defaultView": "top",
      "massInitially": false
    },
    {
      "id": "repair-share",
      "kind": "record",
      "title": "介绍你的改造作品",
      "section": "03 炫酷陀螺",
      "notes": "记录改造前后证据，能转与稳/久分开，不只写“好看”。保存导出，分享时引用一次观察。第二讲再研究为什么旋转能保持姿态、为何会减速倒下，本讲不提前展开角动量。",
      "recordKey": "repair-log",
      "qualitative": true,
      "rows": [
        "让它能转",
        "让它更稳",
        "让它漂亮"
      ],
      "columns": [
        "我改了什么",
        "试转后的发现"
      ]
    }
  ],
  "legacyEntries": [
    "转不倒的陀螺_互动课件.html"
  ]
};
