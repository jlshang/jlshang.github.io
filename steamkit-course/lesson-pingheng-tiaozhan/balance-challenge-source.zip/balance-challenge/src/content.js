window.COURSE={
  "id": "top-lesson1-20261121",
  "title": "对称与平衡",
  "minutes": "第一讲 · 约55–65分钟（未试教）",
  "fallback": "./assets/trapezoid.png",
  "pages": [
    {
      "id": "cover",
      "kind": "cover",
      "title": "对称与平衡",
      "section": "开场",
      "notes": "第一讲：形状、重心位置、高低和改造实践。第二讲再解释旋转与减速。\n配图采用用户2026-11-21提供的透明PNG，保持完整比例；课名为独立文本，叠放在拉起的横幅内，无副标题和小字。\n封面换用用户最后提供的72d5224f图片，课名沿横幅向右上方倾斜10°。",
      "image": "./assets/cover-balance-banner.png",
      "imageAlt": "伙伴们坐在跷跷板上拉起空白横幅"
    },
    {
      "id": "common-tops",
      "kind": "photo",
      "title": "常见的陀螺",
      "section": "开场",
      "notes": "只观察共同点，不提前给结论；点图放大，保留图名。\n【素材署名】木质陀螺：Lacen，Public domain，https://commons.wikimedia.org/wiki/File:Spinning_top.jpg。盘形陀螺：Juni from Kyoto, Japan，CC BY 2.0，https://commons.wikimedia.org/wiki/File:Japanese_top.jpg；许可：https://creativecommons.org/licenses/by/2.0/；裁去外围留白、亮度×1.25。\n对战和金属陀螺来自用户原PPT第2页，仅沿用原教学素材，未核实额外的公开传播许可。\n本轮用macOS Vision离线主体分割、透明PNG等比裁切；无白底框，图名保留。",
      "images": [
        [
          "./assets/common-wood-cutout.png",
          "木质陀螺"
        ],
        [
          "./assets/common-japan-cutout.png",
          "盘形陀螺"
        ],
        [
          "./assets/common-battle-cutout.png",
          "对战陀螺"
        ],
        [
          "./assets/common-metal-cutout.png",
          "金属陀螺"
        ]
      ],
      "imageLayout": "four-cutouts"
    },
    {
      "id": "round-predict",
      "kind": "predict",
      "title": "陀螺一定是圆形吗？",
      "section": "开场",
      "notes": "A是、B不是，只投票不判对错。每点一次记一票；减号撤最近一票，重来清零。卡通图由用户指定的jimeng.mathufo.com生成。\n卡通造型按原图配色制作3D展示，绕自身竖轴旋转，不作为实验模拟；右下可暂停。",
      "options": [
        "是",
        "不是"
      ],
      "vote": true,
      "optionLayout": "cards",
      "cartoonSpin": true
    },
    {
      "id": "part-shape",
      "kind": "chapter",
      "title": "探索陀螺的形状",
      "section": "01 探索陀螺的形状",
      "notes": "请孩子先观察、提出猜想，再动手验证。未实搭、未试教。\n配图为用户2026-11-21指定的透明PNG，保持完整比例，不加白底卡片。",
      "number": "01",
      "titleLines": [
        "探索",
        "陀螺的形状"
      ],
      "image": "./assets/chapter01-top-shapes.png",
      "imageAlt": "伙伴们观察圆形、方形和星形陀螺"
    },
    {
      "id": "shape-select",
      "kind": "observe",
      "title": "你想先搭哪一个？",
      "section": "01 探索陀螺的形状",
      "notes": "直接点击一个立体斜视造型进入拼搭，随后依次搭另外两个。Tab和回车也可选择。无名称标签，图形本身是选择入口。",
      "models": [
        [
          "diamond",
          "红杆菱形"
        ],
        [
          "trapezoid",
          "等腰梯形"
        ],
        [
          "fan",
          "旋转扇面"
        ]
      ],
      "selectBuild": true,
      "defaultView": "showcase",
      "hideModelNames": true
    },
    {
      "id": "diamond-build",
      "kind": "build",
      "title": "拼搭：红杆菱形",
      "section": "01 探索陀螺的形状",
      "notes": "＋按一个结构单元增加，−撤回。同一阶段保留手动镜头与比例。请先查看材料：红菱形4中红围边、2短红及2中黄连中心；梯形上底短蓝、下底长蓝，两腰中黄；短底两端以2中黄接中心球，长底两端以2中蓝接中心球，按用户参考图使用红轴，均为真实孔向和杆长；扇面每片2短蓝、2短绿。四片必须同向。原生模型是依据原图意图合法重构，未宣称逐杆恢复照片。\n【同页完成转杆】菱形与扇面转杆上方中蓝、下方短蓝；梯形按用户参考图改为上中红、下短红，顶部和最下端都加球，底部小球接触桌面。手轻捻转杆，不甩动、不向人投掷。梯形内部蓝黄棍已按参考图纠正，不是仅更换显示颜色。完成后仍需点击底栏下一页，不自动跳。 末步在本页直接用＋装好上下转杆及端球，−可退回转面。先以俯视图拼好转面，末步装上转杆后自动切换立体斜视；撤回转杆回到俯视，重来恢复初始俯视；俯视按钮用于检查形状，回正面按钮用于检查转杆。每种陀螺仅保留一页拼搭，完成后由底栏下一页进入另一造型。",
      "buildFor": "diamond",
      "stages": [
        {
          "model": "diamond-start",
          "label": "先连两条边"
        },
        {
          "model": "diamond-rim",
          "label": "围好外框"
        },
        {
          "model": "diamond-body",
          "label": "连接中心球"
        },
        {
          "model": "diamond",
          "label": "装上转杆",
          "view": "showcase"
        }
      ],
      "top": true,
      "defaultView": "top"
    },
    {
      "id": "trapezoid-build",
      "kind": "build",
      "title": "拼搭：等腰梯形",
      "section": "01 探索陀螺的形状",
      "notes": "＋按一个结构单元增加，−撤回。同一阶段保留手动镜头与比例。请先查看材料：红菱形4中红围边、2短红及2中黄连中心；梯形上底短蓝、下底长蓝，两腰中黄；短底两端以2中黄接中心球，长底两端以2中蓝接中心球，按用户参考图使用红轴，均为真实孔向和杆长；扇面每片2短蓝、2短绿。四片必须同向。原生模型是依据原图意图合法重构，未宣称逐杆恢复照片。\n【同页完成转杆】菱形与扇面转杆上方中蓝、下方短蓝；梯形按用户参考图改为上中红、下短红，顶部和最下端都加球，底部小球接触桌面。手轻捻转杆，不甩动、不向人投掷。梯形内部蓝黄棍已按参考图纠正，不是仅更换显示颜色。完成后仍需点击底栏下一页，不自动跳。 末步在本页直接用＋装好上下转杆及端球，−可退回转面。先以俯视图拼好转面，末步装上转杆后自动切换立体斜视；撤回转杆回到俯视，重来恢复初始俯视；俯视按钮用于检查形状，回正面按钮用于检查转杆。每种陀螺仅保留一页拼搭，完成后由底栏下一页进入另一造型。",
      "buildFor": "trapezoid",
      "stages": [
        {
          "model": "trapezoid-start",
          "label": "先连两条边"
        },
        {
          "model": "trapezoid-rim",
          "label": "围好外框"
        },
        {
          "model": "trapezoid-body",
          "label": "连接中心球"
        },
        {
          "model": "trapezoid",
          "label": "装上转杆",
          "view": "showcase"
        }
      ],
      "top": true,
      "defaultView": "top"
    },
    {
      "id": "fan-build",
      "kind": "build",
      "title": "拼搭：旋转扇面",
      "section": "01 探索陀螺的形状",
      "notes": "＋按一个结构单元增加，−撤回。同一阶段保留手动镜头与比例。请先查看材料：红菱形4中红围边、2短红及2中黄连中心；梯形上底短蓝、下底长蓝，两腰中黄；短底两端以2中黄接中心球，长底两端以2中蓝接中心球，按用户参考图使用红轴，均为真实孔向和杆长；扇面每片2短蓝、2短绿。四片必须同向。原生模型是依据原图意图合法重构，未宣称逐杆恢复照片。\n【同页完成转杆】菱形与扇面转杆上方中蓝、下方短蓝；梯形按用户参考图改为上中红、下短红，顶部和最下端都加球，底部小球接触桌面。手轻捻转杆，不甩动、不向人投掷。梯形内部蓝黄棍已按参考图纠正，不是仅更换显示颜色。完成后仍需点击底栏下一页，不自动跳。 末步在本页直接用＋装好上下转杆及端球，−可退回转面。先以俯视图拼好转面，末步装上转杆后自动切换立体斜视；撤回转杆回到俯视，重来恢复初始俯视；俯视按钮用于检查形状，回正面按钮用于检查转杆。每种陀螺仅保留一页拼搭，完成后由底栏下一页进入另一造型。",
      "buildFor": "fan",
      "stages": [
        {
          "model": "fan-blade-0",
          "label": "从中心球开始"
        },
        {
          "model": "fan-blade-1",
          "label": "搭好一片扇叶"
        },
        {
          "model": "fan-blade-2",
          "label": "添第二片"
        },
        {
          "model": "fan-blade-3",
          "label": "添第三片"
        },
        {
          "model": "fan-blade-4",
          "label": "四片同向扇叶"
        },
        {
          "model": "fan",
          "label": "装上转杆",
          "view": "showcase"
        }
      ],
      "top": true,
      "defaultView": "top"
    },
    {
      "id": "spin-compare",
      "kind": "observe",
      "title": "平衡的挑战",
      "section": "01 探索陀螺的形状",
      "notes": "点击右下眼睛，一次显示三款当前装配的平衡判断：菱形✓、梯形×、旋转扇面✓；再次点击隐藏。不需要逐一选勾叉，不显示重心、轴心或文字注解。此处是本课这三个具体模型装配下的配平示意，与后续理想重心对轴分析对应；不是实测旋转记录，更不是“所有梯形绝对不能转”的结论。实际旋转时长与稳定性仍需实物验证。",
      "models": [
        [
          "diamond",
          "红杆菱形"
        ],
        [
          "trapezoid",
          "等腰梯形"
        ],
        [
          "fan",
          "旋转扇面"
        ]
      ],
      "resultMode": "balance",
      "hideModelNames": true,
      "defaultView": "showcase",
      "balanceResults": {
        "diamond": true,
        "trapezoid": false,
        "fan": true
      }
    },
    {
      "id": "shape-findings",
      "kind": "wall",
      "title": "怎样的转面更容易转得稳？",
      "section": "01 探索陀螺的形状",
      "notes": "标准答案墙保留预设及自由输入。仅完整匹配“旋转对称更容易平衡”这条观点首次贴上墙时撒花；其他观点只收集，不撒花，不按模糊关键词判分。重复同一观点仍计数，不反复庆祝；回翻不重播，重来清空。强调对应材料质量一致时旋转对称便于配平，不将其说成能够旋转的唯一必要条件。",
      "wallLayout": "survey",
      "prompts": [
        "有轴对称就够了",
        "旋转对称更容易平衡",
        "必须两种对称都有"
      ],
      "largeHorizontal": true,
      "celebrateAnswer": "旋转对称更容易平衡"
    },
    {
      "id": "part-center",
      "kind": "chapter",
      "title": "稳稳转的秘密",
      "section": "02 稳稳转的秘密",
      "notes": "请孩子先观察、提出猜想，再动手验证。未实搭、未试教。\n配图采用用户2026-11-21提供的透明PNG，保持完整比例；沿用统一左侧编号/标题、右侧配图布局；编号240px，标题80px。",
      "number": "02",
      "titleLines": [
        "稳稳转的秘密"
      ],
      "image": "./assets/chapter02-rotating-friends.png",
      "imageAlt": "黄色伙伴和绿色伙伴一起旋转"
    },
    {
      "id": "center-intro",
      "kind": "balance",
      "title": "重心：一个物体的重量，都集中在这个点。",
      "section": "02 稳稳转的秘密",
      "notes": "球体、正方体和不规则物体并排展示，每个黄色靶标对应各自的重心。默认捏形模式：直接拖动物体表面，附近形状一起变化，重心实时更新。切换旋转图标后可分别拖动观察立体视角；旋转本身不改变物体的局部重心或体积。各物体下方↺只恢复该物体。翻页返回保留三个形状、视角及操作模式；目录、备注、切换窗口时结束拖动；刷新恢复初态。\n【示意边界】假设均匀材质，重心由当前可见闭合三角网格的体积积分计算，非顶点平均。捏形会改变体积，不是体积守恒的真实橡皮泥模拟。为保持闭合实体，编辑限于沿中心径向的局部变形；靶标作为前景标记显示物体内部重心的投影。"
    },
    {
  "id": "center-hunt",
      "kind": "center-hunt",
      "title": "重心在哪里？",
      "section": "02 稳稳转的秘密",
      "notes": "每个造型只标A、B两个候选点。先请孩子选择一个点，选中只高亮，不立即判对错；再点击右下▶验证。验证分三次点击：第一次悬挂并画蓝色虚线后停住；第二次换挂点并画橙色实线后停住；第三次恢复正向画面并揭晓重心。每步结束都等待再次点击，不自动继续。两条线的交点就是实际重心。正确候选点显示绿色与✓；选错的点显示柔和红色与×，同时指出正确答案。只有真实选对时才撒花；不显示右侧反馈卡片，保留候选点上的对错标记。\n【造型与答案】前两个是均匀拼板：小鱼的B、小靴子的A为实际面积重心。第三个是为本页新拼搭的Zometool小钥匙平面造型（center-hunt-key.vZome）：12球12根短蓝杆，不复用后面陀螺造型；B为理想质量假设下的球杆重心，A为钥匙方框中心的干扰点。两个候选点初态外观相同，不默认选择。右下交叉箭头换造型，↺重新猜当前造型。没有手动挂孔或自由点击找交点步骤。\n【科学边界】前两个图形假设材质均匀、厚度相同，重心依据可见多边形的面积积分计算；悬挂孔、标签、图案质量忽略，厚边仅用于视觉。第三个造型使用原生球杆网格正投影，不将轮廓视为实心板；球质量=1，杆质量=原生坐标长度×0.10，杆质量置于端点中点；这是理想质量示意，未称量、未实搭验证。悬挂点取真实连接球位置；证据线穿过空隙，不是画在实体板上，重心可以位于球杆之间的空处。稳定时重心在挂点竖直下方，两次铅垂线在板上相交于重心。动画为定位示意，不用于测周期。\n【状态】首次验证前可更换A/B；开始后锁定选择，动画中忽略重复点击；第三步前不显示正确/错误状态。离页、目录、备注、后台时只完成当前一步，不跳过后续步骤或补放庆祝；返回保留当前步、选项和结果，刷新恢复初始。验证中重置或换造型会取消本轮，不泄露答案。减少动态效果模式跳过单步动画，仍需逐次点击完成三个步骤。Tab选择A/B，Enter确认；再Tab到验证按钮按Enter。"
    },
    {
      "id": "center-point",
      "kind": "observe",
      "title": "它们的重心在哪里？",
      "section": "02 稳稳转的秘密",
      "notes": "点眼睛显示由球和杆共同计算的重心点，白线是转轴。这里采用理想质量示意：每球质量1，杆质量按长度×0.10，杆重置于端点中点；弯绿杆也用中点近似。不称量不声称这是实物精确重心，需实测配平。重心点不一定在中心球处。\n同材质且零件绕转轴旋转对应时，重心落在轴上；当前梯形略偏轴。不能反推所有非旋转对称造型都偏轴。黄色靶标中心是计算值；青色十字为转轴；标签只用引线，绝不移动重心位置来夸大差异。 新梯形按短蓝上底、长蓝下底和中黄两腰重构；短底两端以中黄连中心，长底两端以中蓝连中心，红色转轴与参考图一致。杆长和孔向均为原生结构。重心依当前模型重新计算，不沿用旧数值。初态为斜视陀螺，点击“俯视图”检查轴心与重心。\n【教师解释】旋转对应的位置一样重，重心就在转杆上。说明移入备注，不在学生画面增加橙色小字。",
      "massToggle": true,
      "top": true,
      "models": [
        [
          "diamond",
          ""
        ],
        [
          "trapezoid",
          ""
        ],
        [
          "fan",
          ""
        ]
      ],
      "modelOptions": {
        "diamond": {
          "frameOverride": 13.333333333333334
        },
        "trapezoid": {
          "frameOverride": 13.333333333333334
        },
        "fan": {
          "frameOverride": 15.833333333333334
        }
      },
      "hideModelNames": true,
      "defaultView": "home",
      "topLabel": "俯视图"
    },
    {
      "id": "center-shift",
      "kind": "build",
      "title": "减少扇叶，重心会怎样？",
      "section": "02 稳稳转的秘密",
      "notes": "初态显示四片完整扇叶与位于转轴上的理想重心。减号每次移除一整片：四瓣→三瓣→两瓣→一瓣，继续依次移除相邻扇叶，直到只剩一片；黄色重心按剩余实际球杆的理想质量计算连续更新。保留杆位、轴杆、底端、相机和尺度。加号逐片补回，重来恢复四瓣；离页返回保留进度。不是移动图形冒充重心变化。质量假设为每球1、杆按长度×0.10，未称量实物。",
      "stages": [
        {
          "model": "fan-high",
          "label": "完整四瓣，重心在转轴上"
        },
        {
          "model": "fan-missing",
          "label": "移除一瓣，观察重心偏移"
        },
        {
          "model": "fan-two-missing",
          "label": "再移除相邻一瓣，再观察重心"
        },
        {
          "model": "fan-one-blade",
          "label": "只留一片扇叶，观察重心"
        }
      ],
      "massToggle": true,
      "top": true,
      "defaultView": "top",
      "massInitially": true,
      "buildAction": "remove"
    },
    {
      "id": "height-compare",
      "kind": "observe",
      "title": "哪个转得更稳？",
      "section": "02 稳稳转的秘密",
      "notes": "同样零件、同轴总长、同底端支点，正面同尺度比较。先选择重心更低的造型：低档显示绿勾并首次撒花；高档红叉、不撒花。右下标签图标在选中低档后可用，点击后以标准盖章动画显示“重心越低更稳定”，替换该处绿勾；再次点击可隐藏。切换到高档清除印章；回翻保留但不重播，重来清空。此章用于同组可比条件下的课堂稳定性讨论，不是任何转速、摩擦、惯量条件下均更稳定或转得更久的定律；仍应结合实物试转。 本页不显示黄色高度测量线，保留重心靶标、标签引线及桌面基线。",
      "models": [
        [
          "fan",
          "低档"
        ],
        [
          "fan-high",
          "高档"
        ]
      ],
      "massToggle": true,
      "ground": true,
      "top": false,
      "defaultView": "front",
      "resultMode": "choice",
      "massInitially": true,
      "correctModel": "fan",
      "hideModelNames": true,
      "choiceStamp": "重心越低更稳定",
      "measureHeight": false
    },
    {
      "id": "part-repair",
      "kind": "chapter",
      "title": "陀螺变身",
      "section": "03 陀螺变身",
      "notes": "请孩子先观察、提出猜想，再动手验证。未实搭、未试教。\n配图为用户2026-11-21指定的透明PNG，保持完整比例，不加白底卡片。",
      "number": "03",
      "titleLines": [
        "陀螺变身"
      ],
      "image": "./assets/chapter03-top-workshop.png",
      "imageAlt": "伙伴们一起动手改造陀螺"
    },
    {
      "id": "repair-observe",
      "kind": "observe",
      "title": "这只陀螺怎么改？",
      "section": "03 陀螺变身",
      "notes": "起点沿原PPT五向红棍造型改为缺一根辐条、转面偏高：四根短红辐条，上短红、下中红轴，上下端小球保留。先观察不对称，后面连续补齐、降转面、再装饰。不提前展示全部改造答案。 学生画面不再显示重心标记，也不提供重心显隐按钮，直接观察并继续改造；以上重心解释仅供教师参考。 首次入场使用斜视，显示转杆及全部球棍，不从俯视开始；仍不显示重心。",
      "model": "upgrade-missing-high",
      "top": true,
      "defaultView": "home",
      "frameOverride": 14,
      "massToggle": false,
      "massInitially": false
    },
    {
      "id": "repair-balance",
      "kind": "build",
      "title": "补上这一根，让转面对称",
      "section": "03 陀螺变身",
      "notes": "保留旧球棍位置和相机，＋仅补缺失的短红辐条。补齐以后恢复五重旋转对称，理想重心回到转轴上，−可撤回。 学生画面不再显示重心标记，也不提供重心显隐按钮，直接观察并继续改造；以上重心解释仅供教师参考。",
      "stages": [
        {
          "model": "upgrade-missing-high",
          "label": "四根辐条，缺一根"
        },
        {
          "model": "upgrade-red-high",
          "label": "补回第五根，恢复旋转对称"
        }
      ],
      "massToggle": false,
      "defaultView": "top",
      "frameOverride": 14,
      "massInitially": false
    },
    {
      "id": "repair-height",
      "kind": "build",
      "title": "把转面降下来",
      "section": "03 陀螺变身",
      "notes": "只交换上短红/下中红为上中红/下短红，转面、球数、杆数、总轴长和底部支点不变。正面同尺度显示转面下降、理想重心降低。不是承诺任何启动条件下都更久，需要实测是否擦地及稳定程度。 学生画面不再显示重心标记，也不提供重心显隐按钮，直接观察并继续改造；以上重心解释仅供教师参考。",
      "stages": [
        {
          "model": "upgrade-red-high",
          "label": "完整对称，但转面偏高"
        },
        {
          "model": "upgrade-red",
          "label": "交换上下轴杆，降低转面"
        }
      ],
      "massToggle": false,
      "defaultView": "front",
      "frameOverride": 14,
      "massInitially": false,
      "ground": true
    },
    {
      "id": "repair-pattern",
      "kind": "build",
      "title": "继续改造，让它转得更稳。",
      "section": "03 陀螺变身",
      "notes": "从第19页已降低的五向红杆陀螺继续，原有红杆、轴杆和底端不变。第一次＋只给五根红棍的外端加球；第二次从这些新球向下插五根中黄棍；第三次给下端加球；第四次从红棍外端球再向下连接五根中黄棍；最后以五根中蓝连接下方五边形。每次保持五重旋转对称，＋推进、−撤回，连续步骤不更换镜头或缩放。中黄棍采用能保持离地的最向下原生孔向，末端球心距底端球心约1.37638模型单位（不是厘米）；不把棍子随意压弯、缩短或拉长。第一步加球在上方，理想重心会略升；其后每组向下构造按每球1、杆长×0.10的理想质量计算使重心逐步降低。末态比初态更低；这是构造示意而非真实动力学仿真，实物间隙和稳定性仍需搭建试转。学生画面不显示重心。默认斜视，俯视可检查五向对称。完整花瓣闭合的末步首次撒花，回翻或重复点击不重播，重来后可重新完成。 2026-11-23补充：下方五边形闭合后可再点一次＋，从原中心球向下方五个顶点各插一根中红棍，不加球、不移动旧杆。五根一起保持五向对称，理想质量重心继续降低；−可退回原末态。此处继续后续外圈拼搭，不提前撒花。\n2026-11-24扩展：用户VZ模型文件夹中的A与原下方五边形一致。保留前七个状态和五根中红中心加固棍，之后依次加入B的十短蓝、五球；C的十短绿、五球；D的十短黄、十球（同时展开五片花瓣）；最后十短黄、五球（闭合五片花瓣）。最终38球、67棍，含原有五根中红加固棍。所有新增位置及连接取自原文件，不拉伸棍长；每组保持五向对称。整页固定视角基准与尺度，为最终花瓣留足空间，拖动和俯视可检查造型，＋添加、−撤回、↺重来。\n【试转提醒】扩大外圈不等于每一步都让重心降低或保证更稳定。花瓣增加后质量分布和转动惯量改变，需实搭检查孔位占用、棍间干涉及转动时是否擦地，再试转比较。短绿棍保留原生弯杆网格；几何连接已核验，尚未实搭试转。",
      "stages": [
        {
          "model": "upgrade-red",
          "label": "保留对称的低转面"
        },
        {
          "model": "upgrade-tip-balls",
          "label": "先给五根红棍的外端加球"
        },
        {
          "model": "upgrade-down-rods",
          "label": "从新球向下插五根中黄棍"
        },
        {
          "model": "upgrade-down-balls",
          "label": "给下方黄棍末端加球"
        },
        {
          "model": "upgrade-down-braced",
          "label": "再向下连接五根中黄棍"
        },
        {
          "model": "upgrade-down-rim",
          "label": "用中蓝棍连好下方五边形"
        },
        {
          "model": "upgrade-down-hub",
          "label": "还能再加：从中心向下接五根中红棍"
        },
        {
          "model": "upgrade-star-base",
          "label": "加十根短蓝棍和五颗球，展开星形底座"
        },
        {
          "model": "upgrade-star-lotus",
          "label": "加十根短绿棍和五颗球，扩展外圈"
        },
        {
          "model": "upgrade-lotus-open",
          "label": "加十根短黄棍和十颗球，展开五片花瓣"
        },
        {
          "model": "upgrade-lotus-bloom",
          "label": "再加十根短黄棍和五颗球，闭合花瓣"
        }
      ],
      "massToggle": false,
      "top": true,
      "frameOverride": 32,
      "defaultView": "home",
      "massInitially": false,
      "celebrateComplete": true
    },
    {
      "id": "homework-tops",
      "kind": "observe",
      "title": "课后挑战：试试转得稳不稳，动手改造更稳！",
      "section": "课后挑战",
      "models": [
        [
          "tri-cyclone",
          "三翼旋风"
        ],
        [
          "star-gear",
          "星芒齿轮"
        ]
      ],
      "defaultView": "showcase",
      "notes": "课后挑战分两页，每页两个原生造型。全组依球杆总数从少到多：三翼旋风→星芒齿轮→钻晶皇冠→双环飞碟；造型下方保留四字名称。每次进入本页采用标准1700ms半周旋转、轻微拉近后自动停在指定最佳斜视角；直接打开与回翻均有入场。拖动、回正面、离页、目录、备注、后台或减少动态会结束入场，不妨碍操作。不作真实试转仿真，稳定性需实物试验。 两页使用相同单行任务标题：“课后挑战：试试转得稳不稳，动手改造更稳！” 造型组下移52px，采用各自的立体斜视角，标题不移动；保留旋转入场。",
      "entrance": "spin",
      "replayEntrance": true
    },
    {
      "id": "homework-tops-2",
      "kind": "observe",
      "title": "课后挑战：试试转得稳不稳，动手改造更稳！",
      "section": "课后挑战",
      "models": [
        [
          "crystal-crown",
          "钻晶皇冠"
        ],
        [
          "double-saucer",
          "双环飞碟"
        ]
      ],
      "defaultView": "showcase",
      "notes": "课后挑战分两页，每页两个原生造型。全组依球杆总数从少到多：三翼旋风→星芒齿轮→钻晶皇冠→双环飞碟；造型下方保留四字名称。每次进入本页采用标准1700ms半周旋转、轻微拉近后自动停在指定最佳斜视角；直接打开与回翻均有入场。拖动、回正面、离页、目录、备注、后台或减少动态会结束入场，不妨碍操作。不作真实试转仿真，稳定性需实物试验。 两页使用相同单行任务标题：“课后挑战：试试转得稳不稳，动手改造更稳！” 造型组下移52px，采用各自的立体斜视角，标题不移动；保留旋转入场。",
      "entrance": "spin",
      "replayEntrance": true
    }
  ],
  "legacyEntries": [
    "转不倒的陀螺_互动课件.html",
    "平衡的挑战_互动课件.html"
  ]
};
