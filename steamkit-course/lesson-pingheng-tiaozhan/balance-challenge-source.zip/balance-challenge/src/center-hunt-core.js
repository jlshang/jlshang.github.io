/* Uniform thin boards. Suspension holes are ideal marked points of negligible size. */
(function(root){'use strict';
const shapes=[
 {name:'小鱼',answer:'B',decoy:[85,55],color:'#e9bd82',points:[[-235,-100],[-150,-55],[-115,-100],[-45,-125],[40,-120],[120,-85],[180,-25],[200,30],[185,85],[130,125],[55,145],[-30,130],[-100,90],[-150,45],[-235,100],[-210,0]],holes:[[-205,-75],[120,-65],[-12,110]],eye:[135,-26]},
 {name:'小靴子',answer:'A',decoy:[-120,-55],color:'#a5c8c2',points:[[-155,-155],[-35,-155],[-10,-130],[-15,45],[130,45],[185,65],[205,110],[185,145],[-155,145],[-180,110],[-180,-120]],holes:[[-140,-130],[180,115],[-160,120]]},
 {name:'小叶子',answer:'B',decoy:[95,-50],color:'#d6c393',points:[[-195,130],[-180,-15],[-130,-100],[-45,-150],[80,-150],[210,-110],[180,20],[105,105],[0,145],[-100,150]],holes:[[-130,-85],[185,-100],[0,125]]}
];
function centroid(points){let a=0,x=0,y=0;points.forEach((p,i)=>{const q=points[(i+1)%points.length],d=p[0]*q[1]-q[0]*p[1];a+=d;x+=(p[0]+q[0])*d;y+=(p[1]+q[1])*d;});return[x/(3*a),y/(3*a)];}
function contains(ps,[x,y]){let inside=false;for(let i=0,j=ps.length-1;i<ps.length;j=i++){const p=ps[i],q=ps[j];if((p[1]>y)!==(q[1]>y)&&x<(q[0]-p[0])*(y-p[1])/(q[1]-p[1])+p[0])inside=!inside;}return inside;}
function world(p,pose){const t=pose.angle*Math.PI/180,c=Math.cos(t),s=Math.sin(t);return[pose.x+p[0]*c-p[1]*s,pose.y+p[0]*s+p[1]*c];}
function local(p,pose){const t=-pose.angle*Math.PI/180,c=Math.cos(t),s=Math.sin(t),x=p[0]-pose.x,y=p[1]-pose.y;return[x*c-y*s,x*s+y*c];}
function hanging(shape,hole){const c=centroid(shape.points),angle=90-Math.atan2(c[1]-hole[1],c[0]-hole[0])*180/Math.PI,p=world(hole,{x:0,y:0,angle});return{x:700-p[0],y:75-p[1],angle};}
function intersection(a,b,c,d){const u=[b[0]-a[0],b[1]-a[1]],v=[d[0]-c[0],d[1]-c[1]],den=u[0]*v[1]-u[1]*v[0];if(Math.abs(den)<1e-8)return null;const t=((c[0]-a[0])*v[1]-(c[1]-a[1])*v[0])/den;return[a[0]+t*u[0],a[1]+t*u[1]];}
function candidates(index){const s=shapes[index],c=centroid(s.points);return ['A','B'].map(label=>({label,point:(label===s.answer?c:s.decoy).slice()}));}
function initial(shape=0){return{version:2,shape,choice:null,verifiedChoice:null,lines:[],revealed:false,solved:false,pose:{x:700,y:285,angle:0}};}
function phase(s){return s.revealed?'done':s.choice?'ready':'guess';}
function canVerify(s){return !s.revealed&&['A','B'].includes(s.choice);}
const api={shapes,centroid,contains,world,local,hanging,intersection,candidates,initial,phase,canVerify};if(typeof module!=='undefined')module.exports=api;else root.CenterHuntCore=api;
})(typeof window==='undefined'?globalThis:window);
