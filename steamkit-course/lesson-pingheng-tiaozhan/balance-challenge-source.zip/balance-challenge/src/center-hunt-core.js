/* Two uniform thin boards and a native Zometool frame under explicit ideal-mass assumptions. */
(function(root){'use strict';
const shapes=[
 {name:'小鱼',answer:'B',decoy:[85,55],color:'#e9bd82',points:[[-235,-100],[-150,-55],[-115,-100],[-45,-125],[40,-120],[120,-85],[180,-25],[200,30],[185,85],[130,125],[55,145],[-30,130],[-100,90],[-150,45],[-235,100],[-210,0]],holes:[[-205,-75],[120,-65],[-12,110]],eye:[135,-26]},
 {name:'小靴子',answer:'A',decoy:[-120,-55],color:'#a5c8c2',points:[[-155,-155],[-35,-155],[-10,-130],[-15,45],[130,45],[185,65],[205,110],[185,145],[-155,145],[-180,110],[-180,-120]],holes:[[-140,-130],[180,115],[-160,120]]},
 {"name":"Zometool 小钥匙","kind":"zometool","answer":"B","decoy":[-104.7213595499958,0],"sourceFile":"center-hunt-key.vZome","nodes":[[-209.4427190999916,-104.7213595499958],[-104.7213595499958,-104.7213595499958],[0.0,-104.7213595499958],[0.0,-0.0],[0.0,104.7213595499958],[-104.7213595499958,104.7213595499958],[-209.4427190999916,104.7213595499958],[-209.4427190999916,-0.0],[104.7213595499958,-0.0],[209.4427190999916,-0.0],[104.7213595499958,104.7213595499958],[209.4427190999916,104.7213595499958]],"ballMasses":[1,1,1,1,1,1,1,1,1,1,1,1],"rods":[{"a":0,"b":1,"color":"blue","shape":"b0","rotation":0,"mass":0.523606797749979},{"a":1,"b":2,"color":"blue","shape":"b0","rotation":0,"mass":0.523606797749979},{"a":2,"b":3,"color":"blue","shape":"b0","rotation":14,"mass":0.523606797749979},{"a":3,"b":4,"color":"blue","shape":"b0","rotation":14,"mass":0.523606797749979},{"a":4,"b":5,"color":"blue","shape":"b0","rotation":2,"mass":0.523606797749979},{"a":5,"b":6,"color":"blue","shape":"b0","rotation":2,"mass":0.523606797749979},{"a":6,"b":7,"color":"blue","shape":"b0","rotation":4,"mass":0.523606797749979},{"a":7,"b":0,"color":"blue","shape":"b0","rotation":4,"mass":0.523606797749979},{"a":3,"b":8,"color":"blue","shape":"b0","rotation":0,"mass":0.523606797749979},{"a":8,"b":9,"color":"blue","shape":"b0","rotation":0,"mass":0.523606797749979},{"a":8,"b":10,"color":"blue","shape":"b0","rotation":14,"mass":0.523606797749979},{"a":9,"b":11,"color":"blue","shape":"b0","rotation":14,"mass":0.523606797749979}],"points":[[-209.4427190999916,-104.7213595499958],[0.0,-104.7213595499958],[209.4427190999916,-0.0],[209.4427190999916,104.7213595499958],[-209.4427190999916,104.7213595499958]],"holes":[[0.0,-104.7213595499958],[209.4427190999916,-0.0]],"image":"./assets/center-hunt-zometool.png","imageBounds":[-260,-190,520,380],"massAssumption":"球=1；每根短蓝杆=原生坐标长度×0.10；杆质量集中于中点；未称量。"}
];
function centroid(points){let a=0,x=0,y=0;points.forEach((p,i)=>{const q=points[(i+1)%points.length],d=p[0]*q[1]-q[0]*p[1];a+=d;x+=(p[0]+q[0])*d;y+=(p[1]+q[1])*d;});return[x/(3*a),y/(3*a)];}
function centerOfMass(s){
 if(s.kind!=='zometool')return centroid(s.points);
 let mass=0,x=0,y=0;
 s.nodes.forEach((p,i)=>{const m=s.ballMasses[i];mass+=m;x+=p[0]*m;y+=p[1]*m;});
 s.rods.forEach(e=>{const a=s.nodes[e.a],b=s.nodes[e.b];mass+=e.mass;x+=(a[0]+b[0])/2*e.mass;y+=(a[1]+b[1])/2*e.mass;});
 return[x/mass,y/mass];
}
function contains(ps,[x,y]){let inside=false;for(let i=0,j=ps.length-1;i<ps.length;j=i++){const p=ps[i],q=ps[j];if((p[1]>y)!==(q[1]>y)&&x<(q[0]-p[0])*(y-p[1])/(q[1]-p[1])+p[0])inside=!inside;}return inside;}
function world(p,pose){const t=pose.angle*Math.PI/180,c=Math.cos(t),s=Math.sin(t);return[pose.x+p[0]*c-p[1]*s,pose.y+p[0]*s+p[1]*c];}
function local(p,pose){const t=-pose.angle*Math.PI/180,c=Math.cos(t),s=Math.sin(t),x=p[0]-pose.x,y=p[1]-pose.y;return[x*c-y*s,x*s+y*c];}
function hanging(shape,hole){const c=centerOfMass(shape),angle=90-Math.atan2(c[1]-hole[1],c[0]-hole[0])*180/Math.PI,p=world(hole,{x:0,y:0,angle});return{x:700-p[0],y:75-p[1],angle};}
function intersection(a,b,c,d){const u=[b[0]-a[0],b[1]-a[1]],v=[d[0]-c[0],d[1]-c[1]],den=u[0]*v[1]-u[1]*v[0];if(Math.abs(den)<1e-8)return null;const t=((c[0]-a[0])*v[1]-(c[1]-a[1])*v[0])/den;return[a[0]+t*u[0],a[1]+t*u[1]];}
function candidates(index){const s=shapes[index],c=centerOfMass(s);return ['A','B'].map(label=>({label,point:(label===s.answer?c:s.decoy).slice()}));}
function initial(shape=0){return{version:2,shape,choice:null,verifiedChoice:null,lines:[],revealed:false,solved:false,pose:{x:700,y:285,angle:0}};}
function phase(s){return s.revealed?'done':s.choice?'ready':'guess';}
function canVerify(s){return !s.revealed&&['A','B'].includes(s.choice);}
const api={shapes,centroid,centerOfMass,contains,world,local,hanging,intersection,candidates,initial,phase,canVerify};if(typeof module!=='undefined')module.exports=api;else root.CenterHuntCore=api;
})(typeof window==='undefined'?globalThis:window);
