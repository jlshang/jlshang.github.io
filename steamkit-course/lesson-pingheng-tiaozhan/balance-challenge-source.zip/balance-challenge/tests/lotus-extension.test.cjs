const test=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
global.window={};require('../src/content.js');require('../src/model-data.js');
const D=window.MODEL_DATA,C=require('../src/top-core.js'),P=window.COURSE.pages.find(p=>p.id==='repair-pattern'),phi=(1+Math.sqrt(5))/2;
const old=['upgrade-red','upgrade-tip-balls','upgrade-down-rods','upgrade-down-balls','upgrade-down-braced','upgrade-down-rim','upgrade-down-hub'];
const added=['upgrade-star-base','upgrade-star-lotus','upgrade-lotus-open','upgrade-lotus-bloom'];
const key=e=>[e.a,e.b].sort((a,b)=>a-b).join(':');
test('P23 keeps seven existing states and appends four native flower stages',()=>{
 a.deepEqual(P.stages.map(s=>s.model),[...old,...added]);a.equal(P.frameOverride,32);a.ok(!P.massToggle);
});
test('every added stage preserves old parts, tip, camera basis and fivefold ball symmetry',()=>{
 let prev=D.models[old.at(-1)];
 for(const id of added){const m=D.models[id];a.ok(m,id);
  a.ok(prev.edges.every(e=>m.edges.some(f=>key(e)===key(f)&&e.shape===f.shape)));
  a.ok(prev.balls.every(i=>m.balls.includes(i)));
  for(const i of new Set([...prev.balls,...prev.edges.flatMap(e=>[e.a,e.b])]))a.deepEqual(m.points[i],prev.points[i]);
  a.deepEqual(m.quaternion,prev.quaternion);a.deepEqual(m.center,prev.center);a.equal(m.tip,prev.tip);
  a.ok(C.axisOffset(m)<1e-6);
  const pts=m.balls.map(i=>C.worldVector(m,m.points[i])),t=2*Math.PI/5;
  for(const p of pts){const q=[p[0]*Math.cos(t)-p[2]*Math.sin(t),p[1],p[0]*Math.sin(t)+p[2]*Math.cos(t)];
   a.ok(pts.some(v=>Math.hypot(...q.map((x,k)=>x-v[k]))<1e-5),id+' symmetry');a.ok(p[1]>=-1e-6);}
  prev=m;
 }
});
test('final flower includes every supplied vertex and edge, plus the five existing red hub braces',()=>{
 const doc=JSON.parse(fs.readFileSync(path.join(__dirname,'../reference/vz-models-20261124/D_lotus_bloom.lite.json'))),m=D.models[added.at(-1)];a.ok(m);
 const pts=doc.vertices.map(p=>p.map(v=>(v[0]+v[1]*phi)/v[2])),mapping=pts.map(p=>m.points.findIndex(q=>Math.hypot(...p.map((x,k)=>x-q[k]))<1e-6));
 a.ok(mapping.every(i=>i>=0));a.equal(m.balls.length,38);a.equal(m.edges.length,67);
 for(const b of doc.draft.mesh.balls)a.ok(m.balls.includes(mapping[b.vertex]));
 for(const e of doc.draft.mesh.struts){const [x,y]=e.vertices;a.ok(m.edges.some(f=>key(f)===key({a:mapping[x],b:mapping[y]})));}
});
test('all added rods use native lengths and rotations including bent-green geometry',()=>{
 const bases={b:[2*phi**2,0,0],y:[phi**3,0,-phi],r:[phi**3,phi**2,0],g:[phi**4,phi**2,-1]};
 for(const id of added){const m=D.models[id];a.ok(m);
  for(const e of m.edges){const v=bases[e.shape[0]].map(x=>x*phi**Number(e.shape[1])),r=D.rotations[e.rotation];
   for(let k=0;k<3;k++)a.ok(Math.abs(m.points[e.b][k]-m.points[e.a][k]-r[k].reduce((s,x,j)=>s+x*v[j],0))<1e-5,id);}
 }
});
