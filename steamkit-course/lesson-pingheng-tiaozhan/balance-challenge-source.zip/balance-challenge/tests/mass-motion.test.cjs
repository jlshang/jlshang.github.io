const test=require('node:test'),a=require('node:assert/strict'),C=require('../src/top-core.js');
test('one frame and six identical balls have a conserved total mass in every state',()=>{for(let s=0;s<4;s++){const ps=C.massMotionPositions(s);a.equal(ps.length,6);for(let i=0;i<6;i++){a.equal(ps[i][1],275);a.ok(ps[i][0]>180+27&&ps[i][0]<1220-27);if(i)a.ok(ps[i][0]-ps[i-1][0]>=54);}}});
test('whole-object center includes symmetric frame mass; right shift and symmetric spread differ',()=>{a.deepEqual(C.massMotionCenter(C.massMotionPositions(0)),[700,275]);a.deepEqual(C.massMotionCenter(C.massMotionPositions(1)),[778.75,275]);a.deepEqual(C.massMotionPositions(2),C.massMotionPositions(0));a.deepEqual(C.massMotionCenter(C.massMotionPositions(3)),[700,275]);});
test('every animated intermediate marker matches the actual six moving balls plus the frame',()=>{for(let s=1;s<4;s++){const from=C.massMotionPositions(s-1),to=C.massMotionPositions(s),c0=C.massMotionCenter(from),c1=C.massMotionCenter(to);for(let j=0;j<=20;j++){const t=j/20,ps=from.map((p,i)=>p.map((x,k)=>x+(to[i][k]-x)*t)),expected=[(1400+ps.reduce((v,p)=>v+p[0],0))/8,(550+ps.reduce((v,p)=>v+p[1],0))/8];const got=C.massMotionCenter(ps);got.forEach((x,k)=>{a.ok(Math.abs(x-expected[k])<1e-9);a.ok(Math.abs(x-(c0[k]+(c1[k]-c0[k])*t))<1e-9);});}}});
test('dragging a ball respects the rail and pushes neighbors without overlap or mass changes',()=>{
 const initial=C.massMotionPositions(0);
 for(let i=0;i<6;i++)for(const x of [-1000,228,400,700,1000,1172,2000]){
  const ps=C.dragMassPositions(initial,i,x);a.equal(ps.length,6);
  for(let j=0;j<6;j++){a.equal(ps[j][1],275);a.ok(ps[j][0]>=228&&ps[j][0]<=1172);if(j)a.ok(ps[j][0]-ps[j-1][0]>=70);}
  a.equal(C.massMotionCenter(ps)[0],(1400+ps.reduce((n,p)=>n+p[0],0))/8);
 }
 a.deepEqual(initial,C.massMotionPositions(0));
 const right=C.dragMassPositions(initial,5,1100);a.ok(C.massMotionCenter(right)[0]>700);a.deepEqual(right.slice(0,5),initial.slice(0,5));
 const symmetric=C.dragMassPositions(right,0,300);a.equal(C.massMotionCenter(symmetric)[0],700);
});
