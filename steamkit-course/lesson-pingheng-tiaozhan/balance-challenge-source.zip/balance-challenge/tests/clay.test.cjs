const test=require('node:test'),a=require('node:assert/strict'),fs=require('fs');
const C=fs.existsSync(__dirname+'/../src/clay-core.js')?require('../src/clay-core.js'):{};
const close=(x,y)=>a.ok(Math.abs(x-y)<1e-7,`${x} != ${y}`);
test('uniform sheet centroid weights area, including concave shapes and either winding',()=>{
 a.equal(typeof C.mass,'function');
 for(const pts of [[[0,0],[6,0],[0,6]],[[0,6],[6,0],[0,0]]]){const m=C.mass(pts);close(m.area,18);close(m.center[0],2);close(m.center[1],2);}
 // An L made of 4x1 and 1x3 rectangles has area 7 and centroid 9.5/7.
 const m=C.mass([[0,0],[4,0],[4,1],[1,1],[1,4],[0,4]]);
 close(m.area,7);m.center.forEach(x=>close(x,9.5/7));
});
test('circle and triangle have expected centroids; crescent center lies in its empty region',()=>{
 a.equal(typeof C.preset,'function');
 const circle=C.preset('circle');close(C.mass(circle).center[0],700);close(C.mass(circle).center[1],310);
 const triangle=C.preset('triangle');close(C.mass(triangle).center[0],700);close(C.mass(triangle).center[1],310);
 for(const id of ['circle','triangle','crescent'])a.ok(C.valid(C.preset(id)),id);
 const moon=C.preset('crescent');a.equal(C.contains(moon,C.mass(moon).center),false);
});
test('pinching preserves a single noncrossing sheet inside the drawing area',()=>{
 a.equal(typeof C.deform,'function');
 const original=C.preset('circle'),copy=JSON.stringify(original);
 let pts=C.deform(original,0,170,-40);a.ok(C.mass(pts).center[0]>700);a.equal(JSON.stringify(original),copy);
 for(let j=0;j<80;j++){pts=C.deform(pts,j%pts.length,Math.sin(j*37)*1200,Math.cos(j*13)*900);a.ok(C.valid(pts));a.ok(pts.every(([x,y])=>x>=260&&x<=1220&&y>=105&&y<=525));}
 a.equal(C.simple([[0,0],[2,2],[0,2],[2,0]]),false);
});
