const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
global.window={};require('../src/content.js');
const pages=window.COURSE.pages,by=id=>pages.find(p=>p.id===id);
test('cover uses supplied banner artwork and retains an editable course title',()=>{
 const p=by('cover');assert.equal(p.image,'./assets/cover-balance-banner.png');assert.equal(p.model,undefined);assert.equal(p.title,'对称与平衡');
 assert.equal(window.COURSE.title,p.title);
 assert.ok(fs.existsSync(path.join(__dirname,'../src',p.image)));
});
test('02 uses supplied rotating characters in the established chapter layout',()=>{
 const p=by('part-center');assert.equal(p.image,'./assets/chapter02-rotating-friends.png');assert.equal(p.model,undefined);
 assert.equal(p.number,'02');assert.equal(p.title,'稳稳转的秘密');assert.ok(!p.singleLineChapter);
 assert.ok(fs.existsSync(path.join(__dirname,'../src',p.image)));
});
test('cover banner placement is scoped and does not change other title tiers',()=>{
 const css=fs.readFileSync(path.join(__dirname,'../src/styles.css'),'utf8');
 assert.match(css,/#page\[data-page-id="cover"\] h1/);
 assert.match(css,/#page\[data-page-id="cover"\] \.cover-image/);
});
test('01 and 03 use the two supplied illustrations in the requested order',()=>{
 const first=by('part-shape'),last=by('part-repair');
 assert.equal(first.image,'./assets/chapter01-top-shapes.png');assert.ok(!first.singleLineChapter);
 assert.equal(last.image,'./assets/chapter03-top-workshop.png');
 for(const p of [first,last]){assert.equal(p.model,undefined);assert.ok(fs.existsSync(path.join(__dirname,'../src',p.image)));}
});
