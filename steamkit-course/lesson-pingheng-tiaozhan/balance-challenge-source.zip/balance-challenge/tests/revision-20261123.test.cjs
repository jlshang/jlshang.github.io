const test=require('node:test'),a=require('node:assert/strict');
global.window={};require('../src/content.js');require('../src/model-data.js');
const P=window.COURSE.pages,D=window.MODEL_DATA,C=require('../src/top-core.js'),by=id=>P.find(p=>p.id===id);
test('requested exact titles and matching final two homework pages',()=>{
 for(const [id,title] of Object.entries({'shape-findings':'怎样的转面更容易转得稳？','center-point':'它们的重心在哪里？','height-compare':'哪个转得更稳？','repair-observe':'这只陀螺怎么改？','repair-pattern':'继续改造，让它转得更稳。','homework-tops':'课后挑战：试试转得稳不稳，动手改造更稳！'}))a.equal(by(id).title,title);
 a.equal(by('homework-tops').subtitle,undefined);a.equal(by('homework-tops').titleLines,undefined);a.equal(P.length,23);
 a.equal(by('homework-tops-2').title,by('homework-tops').title);a.deepEqual(by('homework-tops-2').titleLines,by('homework-tops').titleLines);
});
test('P16 initially shows actual 3D tops and offers top view',()=>{const p=by('center-point');a.equal(p.defaultView,'home');a.equal(p.topLabel,'俯视图');for(const [id]of p.models){const m=D.models[id];a.ok(m.balls.includes(m.tip));a.ok(m.edges.some(e=>e.a===m.tip||e.b===m.tip));}});
test('P18 removes only height measurement, retaining COM, ground and configured stamp',()=>{const p=by('height-compare');a.equal(p.measureHeight,false);a.equal(p.ground,true);a.equal(p.massInitially,true);a.equal(p.choiceStamp,'重心越低更稳定');});
test('trapezoid has short/long blue bases, medium yellow sides and medium spokes',()=>{const m=D.models.trapezoid;const rim=m.edges.filter(e=>e.a>0&&e.a<5&&e.b>0&&e.b<5);a.deepEqual(rim.map(e=>e.shape).sort(),['b0','b2','y1','y1']);const spokes=m.edges.filter(e=>e.a===0&&e.b>0&&e.b<5);a.deepEqual(spokes.map(e=>e.shape).sort(),['b1','b1','y1','y1']);});
test('P23 first addition only caps all five red ends with balls',()=>{const ids=by('repair-pattern').stages.map(s=>s.model),start=D.models[ids[0]],first=D.models[ids[1]];a.equal(ids[0],by('repair-height').stages.at(-1).model);a.deepEqual(first.edges,start.edges);a.deepEqual(first.balls.filter(i=>!start.balls.includes(i)),[1,2,3,4,5]);});
test('P23 cumulative downward groups retain parts, native holes, symmetry and lower COM',()=>{
 const ids=by('repair-pattern').stages.slice(0,7).map(s=>s.model),phi=(1+Math.sqrt(5))/2,bases={b:[2*phi**2,0,0],y:[phi**3,0,-phi],r:[phi**3,phi**2,0]};
 for(let n=1;n<ids.length;n++){const m=D.models[ids[n]],prev=D.models[ids[n-1]],key=e=>`${e.a}:${e.b}:${e.shape}`,old=new Set(prev.edges.map(key));
  for(const e of prev.edges)a.ok(m.edges.some(f=>key(e)===key(f)),ids[n]);for(const i of prev.balls)a.ok(m.balls.includes(i));for(const e of prev.edges)for(const i of [e.a,e.b])a.deepEqual(m.points[i],prev.points[i]);
  a.deepEqual(m.points[m.tip],prev.points[prev.tip]);a.ok(C.axisOffset(m)<1e-6);
  if(n>1)a.ok(C.worldVector(m,C.centroid(m))[1]<C.worldVector(prev,C.centroid(prev))[1],ids[n]+' lowers COM');
  for(const e of m.edges){const v=bases[e.shape[0]].map(x=>x*phi**Number(e.shape[1])),r=D.rotations[e.rotation];for(let k=0;k<3;k++)a.ok(Math.abs(m.points[e.b][k]-m.points[e.a][k]-r[k].reduce((s,x,j)=>s+x*v[j],0))<1e-5);
   if(!old.has(key(e))&&e.color==='yellow'){const from=C.worldVector(m,m.points[e.a]),to=C.worldVector(m,m.points[e.b]);a.equal(e.shape,'y1');a.ok(from[1]-to[1]>5.8,'yellow branch must descend to lowest safe native level');a.ok(e.a>=1&&e.a<=5,'from red-end connector');}}
  const pts=m.balls.map(i=>C.worldVector(m,m.points[i]));for(const p of pts){const t=2*Math.PI/5,q=[p[0]*Math.cos(t)-p[2]*Math.sin(t),p[1],p[0]*Math.sin(t)+p[2]*Math.cos(t)];a.ok(pts.some(v=>Math.hypot(...q.map((x,k)=>x-v[k]))<1e-5),'fivefold balls');}
  for(const p of pts)a.ok(p[1]>=-1e-6,'no ball below tip');
 }
});

test('reference trapezoid connects short-base ends with yellow and long-base ends with blue',()=>{const m=D.models.trapezoid;for(const i of [1,2])a.equal(m.edges.find(e=>e.a===0&&e.b===i).shape,'y1');for(const i of [3,4])a.equal(m.edges.find(e=>e.a===0&&e.b===i).shape,'b1');a.ok(m.edges.filter(e=>e.b>=5).every(e=>e.color==='red'),'reference red shaft');});
test('seventh state keeps five downward medium-red hub braces only',()=>{const ss=by('repair-pattern').stages.slice(0,7),last=D.models[ss.at(-1).model],prev=D.models[ss.at(-2).model];a.equal(ss.at(-1).model,'upgrade-down-hub');const added=last.edges.filter(e=>!prev.edges.some(f=>f.a===e.a&&f.b===e.b));a.equal(added.length,5);a.ok(added.every(e=>e.a===0&&e.b>=13&&e.b<=17&&e.shape==='r1'));a.deepEqual(last.balls,prev.balls);});
