const test=require('node:test'),a=require('node:assert/strict');
global.window={};require('../src/content.js');require('../src/model-data.js');
const pages=window.COURSE.pages,models=window.MODEL_DATA.models,C=require('../src/top-core.js');
test('each initial top has one complete building page ending with its shaft',()=>{
 a.equal(pages.length,23);
 for(const id of C.shapes){
  const ps=pages.filter(p=>p.buildFor===id);a.equal(ps.length,1);
  const p=ps[0];a.equal(p.id,id+'-build');a.equal(p.stages.at(-1).model,id);
  a.equal(p.stages.length,id==='fan'?6:4);a.equal(p.defaultView,'top');a.equal(p.stages.at(-1).view,'showcase');a.equal(p.top,true);
  const before=models[p.stages.at(-2).model],final=models[id];
  a.ok(before.edges.every(e=>final.edges.some(f=>e.a===f.a&&e.b===f.b&&e.shape===f.shape)));
  a.ok(before.balls.every(i=>final.balls.includes(i)));a.equal(final.edges.length-before.edges.length,2);
  a.ok(final.balls.includes(final.tip));a.deepEqual(final.points,before.points);
 }
 a.equal(pages.filter(p=>p.id.endsWith('-axis')).length,0);
});
test('choosing any first top visits exactly three complete building pages then comparison',()=>{
 for(const first of C.shapes){
  const route=C.route(pages,first),builds=route.filter(p=>p.buildFor);
  a.deepEqual(builds.map(p=>p.buildFor),C.order(first));
  a.deepEqual(route.filter(p=>!p.buildFor).map(p=>p.id),pages.filter(p=>!p.buildFor).map(p=>p.id));
  const i=route.findIndex(p=>p.buildFor);
  a.equal(route[i+3].id,'spin-compare');
  a.deepEqual(route.slice(i,i+3).map(p=>p.stages.at(-1).model),C.order(first));
 }
});
