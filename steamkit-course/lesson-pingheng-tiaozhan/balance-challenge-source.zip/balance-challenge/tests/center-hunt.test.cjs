const test=require('node:test'),a=require('node:assert/strict');
const C=require('../src/center-hunt-core.js');
const close=(x,y)=>a.ok(Math.abs(x-y)<1e-7,`${x} != ${y}`);
test('uniform board centroid uses area, independent of winding',()=>{
 for(const ps of [[[0,0],[6,0],[0,6]],[[0,6],[6,0],[0,0]]])C.centroid(ps).forEach(x=>close(x,2));
 const c=C.centroid([[0,0],[4,0],[4,1],[1,1],[1,4],[0,4]]);c.forEach(x=>close(x,9.5/7));
});
test('each hanging pose keeps chosen hole fixed and center vertically below it',()=>{
 for(const shape of C.shapes)for(const hole of shape.holes){
  a.ok(C.contains(shape.points,hole));const pose=C.hanging(shape,hole),p=C.world(hole,pose),c=C.world(C.centroid(shape.points),pose);
  close(p[0],700);close(p[1],75);close(c[0],700);a.ok(c[1]>75);
  for(const v of shape.points){const w=C.world(v,pose);a.ok(w[0]>200&&w[0]<1200&&w[1]>20&&w[1]<550,shape.name);}
 }
});
test('every pair of distinct suspension traces intersects at the true area centroid',()=>{
 for(const s of C.shapes)for(let i=0;i<s.holes.length;i++)for(let j=i+1;j<s.holes.length;j++){
  const c=C.centroid(s.points),u=s.holes[i].map((x,k)=>x-c[k]),v=s.holes[j].map((x,k)=>x-c[k]);a.ok(Math.abs(u[0]*v[1]-u[1]*v[0])/(Math.hypot(...u)*Math.hypot(...v))>.5,'clearly crossing traces');const p=C.intersection(s.holes[i],c,s.holes[j],c);a.ok(p);p.forEach((v,k)=>close(v,c[k]));
 }
});
test('each board has two equally valid-looking candidates, one at the exact centroid',()=>{
 for(let i=0;i<C.shapes.length;i++){const choices=C.candidates(i),c=C.centroid(C.shapes[i].points);a.deepEqual(choices.map(x=>x.label),['A','B']);a.equal(choices.length,2);const correct=choices.filter(x=>Math.hypot(x.point[0]-c[0],x.point[1]-c[1])<1e-7);a.equal(correct.length,1);a.equal(correct[0].label,C.shapes[i].answer);for(const x of choices)a.ok(C.contains(C.shapes[i].points,x.point));a.ok(Math.hypot(...choices[0].point.map((v,k)=>v-choices[1].point[k]))>75);}
 a.ok(new Set(C.shapes.map(s=>s.answer)).size>1);
});
test('no default guess or answer; choice does not reveal until verification',()=>{
 const s=C.initial();a.equal(s.choice,null);a.equal(s.revealed,false);a.equal(C.canVerify(s),false);s.choice='A';a.equal(C.phase(s),'ready');a.equal(s.revealed,false);a.equal(C.canVerify(s),true);s.revealed=true;a.equal(C.phase(s),'done');a.equal(C.canVerify(s),false);
});
test('game is directly after the three solids and before the top COM comparison',()=>{
 global.window={};require('../src/content.js');const ps=window.COURSE.pages,i=ps.findIndex(p=>p.id==='center-intro');a.equal(ps[i+1].id,'center-hunt');a.equal(ps[i+2].id,'center-point');a.equal(ps.length,23);
});
