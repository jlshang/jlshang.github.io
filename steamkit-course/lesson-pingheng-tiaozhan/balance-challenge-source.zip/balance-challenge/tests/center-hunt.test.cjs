const test=require('node:test'),a=require('node:assert/strict');
const C=require('../src/center-hunt-core.js');
const close=(x,y)=>a.ok(Math.abs(x-y)<1e-7,`${x} != ${y}`);
test('uniform board centroid uses area, independent of winding',()=>{
 for(const ps of [[[0,0],[6,0],[0,6]],[[0,6],[6,0],[0,0]]])C.centroid(ps).forEach(x=>close(x,2));
 const c=C.centroid([[0,0],[4,0],[4,1],[1,1],[1,4],[0,4]]);c.forEach(x=>close(x,9.5/7));
});
test('each hanging pose keeps chosen hole fixed and center vertically below it',()=>{
 for(const shape of C.shapes)for(const hole of shape.holes){
  if(shape.kind!=='zometool')a.ok(C.contains(shape.points,hole));const pose=C.hanging(shape,hole),p=C.world(hole,pose),c=C.world(C.centerOfMass(shape),pose);
  close(p[0],700);close(p[1],75);close(c[0],700);a.ok(c[1]>75);
  for(const v of shape.points){const w=C.world(v,pose);a.ok(w[0]>200&&w[0]<1200&&w[1]>20&&w[1]<550,shape.name);}
 }
});
test('every pair of distinct suspension traces intersects at the true area centroid',()=>{
 for(const s of C.shapes)for(let i=0;i<s.holes.length;i++)for(let j=i+1;j<s.holes.length;j++){
  const c=C.centerOfMass(s),u=s.holes[i].map((x,k)=>x-c[k]),v=s.holes[j].map((x,k)=>x-c[k]);a.ok(Math.abs(u[0]*v[1]-u[1]*v[0])/(Math.hypot(...u)*Math.hypot(...v))>.5,'clearly crossing traces');const p=C.intersection(s.holes[i],c,s.holes[j],c);a.ok(p);p.forEach((v,k)=>close(v,c[k]));
 }
});
test('each board has two equally valid-looking candidates, one at the exact centroid',()=>{
 for(let i=0;i<C.shapes.length;i++){const choices=C.candidates(i),c=C.centerOfMass(C.shapes[i]);a.deepEqual(choices.map(x=>x.label),['A','B']);a.equal(choices.length,2);const correct=choices.filter(x=>Math.hypot(x.point[0]-c[0],x.point[1]-c[1])<1e-7);a.equal(correct.length,1);a.equal(correct[0].label,C.shapes[i].answer);if(C.shapes[i].kind!=='zometool')for(const x of choices)a.ok(C.contains(C.shapes[i].points,x.point));a.ok(Math.hypot(...choices[0].point.map((v,k)=>v-choices[1].point[k]))>75);}
 a.ok(new Set(C.shapes.map(s=>s.answer)).size>1);
});
test('no default guess or answer; choice does not reveal until verification',()=>{
 const s=C.initial();a.equal(s.choice,null);a.equal(s.revealed,false);a.equal(C.canVerify(s),false);s.choice='A';a.equal(C.phase(s),'ready');a.equal(s.revealed,false);a.equal(C.canVerify(s),true);s.revealed=true;a.equal(C.phase(s),'done');a.equal(C.canVerify(s),false);
});
test('game is directly after the three solids and before the top COM comparison',()=>{
 global.window={};require('../src/content.js');const ps=window.COURSE.pages,i=ps.findIndex(p=>p.id==='center-intro');a.equal(ps[i+1].id,'center-hunt');a.equal(ps[i+2].id,'center-point');a.equal(ps.length,23);
});

test('frame center weighs balls and rods, not a filled-in outline',()=>{
 const frame={kind:'zometool',nodes:[[0,0],[4,0]],ballMasses:[1,3],rods:[{a:0,b:1,mass:4}]};
 a.deepEqual(C.centerOfMass(frame),[2.5,0]);
 frame.rods[0].mass=0;a.deepEqual(C.centerOfMass(frame),[3,0]);
});
test('third figure is a new planar key, with native legal rods and ball suspension points',()=>{
 const s=C.shapes[2];a.equal(s.sourceFile,'center-hunt-key.vZome');
 const native=require('../models/center-hunt-key-native.json'),assembly=require('../models/assembly.json');a.equal(s.kind,'zometool');a.equal(s.nodes.length,12);a.equal(s.rods.length,12);
 for(let i=0;i<12;i++){close(s.nodes[i][0],(native.points[i][0]-5.23606797749979)*20);close(s.nodes[i][1],-native.points[i][2]*20);close(native.points[i][1],0);}
 for(let i=0;i<12;i++){const e=s.rods[i],original=native.edges[i];a.equal(e.a,original.a);a.equal(e.b,original.b);a.equal(e.shape,'b0');a.equal(e.rotation,original.rotation);const vector=native.points[e.b].map((v,k)=>v-native.points[e.a][k]);vector.forEach((v,k)=>close(v,assembly.rotations[e.rotation][k][0]*5.23606797749979));close(e.mass,Math.hypot(...vector)*.1);}
 const c=C.centerOfMass(s);close(c[0],-20.452628528252088);close(c[1],14.454491321747906);
 a.ok(Math.hypot(c[0]-C.centroid(s.points)[0],c[1]-C.centroid(s.points)[1])>1,'hull area must not determine frame COM');
 for(const hole of s.holes)a.ok(s.nodes.some(p=>Math.hypot(p[0]-hole[0],p[1]-hole[1])<1e-7));
});
